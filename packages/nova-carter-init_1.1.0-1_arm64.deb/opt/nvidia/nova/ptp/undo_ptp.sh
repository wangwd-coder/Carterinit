#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
sudo mv /lib/systemd/system/ptp4l.service.bak /lib/systemd/system/ptp4l.service 2>/dev/null
sudo mv /lib/systemd/system/phc2sys.service.bak /lib/systemd/system/phc2sys.service 2>/dev/null
# Don't start services on boot
sudo systemctl disable ptp4l.service
sudo systemctl disable phc2sys.service
