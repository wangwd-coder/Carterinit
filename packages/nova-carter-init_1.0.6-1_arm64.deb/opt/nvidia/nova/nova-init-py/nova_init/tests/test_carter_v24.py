#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
import pytest
from nova_init.tests.filesystem import (CameraType, FS_CAMERA_PARAMS, FS_IMU_PARAMS)

from nova_init.tests.filesystem import (test_filesystem_dev, test_filesystem_ssd,
                                        test_filesystem_camera, test_filesystem_imu,
                                        test_exe_version)
from nova_init.tests.services import (test_service)
from nova_init.tests.hawk import (TestHawkEeprom, setup_hawk_eeprom, HAWK_EEPROM_INPUTS)

from nova_init.tests.bmi088 import (TestBmi088Imu, setup_bmi)

from nova_init.tests.hesai import test_hesai_ping, test_ptp_lock

from nova_init.tests.time_sync import (test_latch, test_phc2sys_offsets, test_phc2sys_frequency)

from nova_init.tests.calibration import (test_calibration_host)


@pytest.fixture
def hesai_ip():
    return "192.168.1.201"


@pytest.fixture
def host_ip():
    return "192.168.1.100"


setup_hawk_eeprom = pytest.fixture(setup_hawk_eeprom, scope='class', params=[(1), (2), (3), (4)])
setup_bmi = pytest.fixture(setup_bmi, scope='class', params=[(69), (68)])

FS_CAMERA_PARAMS += [
    (CameraType.HAWK, 4),
    (CameraType.OWL, 4),
]
FS_IMU_PARAMS += [
    (CameraType.HAWK, 2),
]
