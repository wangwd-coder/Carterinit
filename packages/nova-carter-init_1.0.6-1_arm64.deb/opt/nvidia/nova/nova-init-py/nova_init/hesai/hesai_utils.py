#!/usr/bin/python3
##############################################################################
# Copyright (c) 2022, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

from enum import Enum, EnumMeta, auto
import json
import shlex
import subprocess


# https://stackoverflow.com/a/65225753
class MetaEnum(EnumMeta):

    def __contains__(cls, item):
        try:
            cls(item)
        except ValueError:
            return False
        return True


class BaseEnum(Enum, metaclass=MetaEnum):
    pass


class CgiAction(BaseEnum):
    GET = 0
    SET = auto()


class HesaiModelType(BaseEnum):
    PANDARXT32 = 0
    PANDAR128E3 = auto()


class HesaiReturnMode(BaseEnum):
    LAST = 0
    STRONGEST = auto()
    LAST_STRONGEST = auto()
    FIRST = auto()
    FIRST_LAST = auto()
    FIRST_STRONGEST = auto()


class HesaiPtpProfile(BaseEnum):
    IEEE1588V2 = 0
    IEEE8021AS = auto()


class HesaiPtpNetwork(BaseEnum):
    UDP = 0
    L2 = auto()


class HesaiClockSource(BaseEnum):
    GPS = 0
    PTP = auto()


class HesaiPtpStatusType(BaseEnum):
    LOCKED = 0
    TRACKING = auto()
    FREE_RUN = auto()
    FROZEN = auto()


class HesaiPtpStatus:

    def __init__(self, status: str, offset) -> None:
        status = status.upper().replace(" ", "_")
        self.status = HesaiPtpStatusType[status]
        self.offset = int(offset)


def send_cgi(action: CgiAction,
             obj: str,
             key="",
             value="",
             ip="192.168.1.201",
             cgi_file="pandar",
             timeout=1,
             tries=1):
    """Sends a CGI command with given action, extra args, and IP/CGI file reference."""
    cgi_url = f"http://{ip}/{cgi_file}.cgi?action={action.name.lower()}&object={obj}"
    if key != "":
        cgi_url += f"&key={key}"
        if value != "":
            if isinstance(value, dict):    # dict needs to be printed with double quotes
                value = json.dumps(value)
            cgi_url += f"&value={value}"
    cmd = f"wget -t {tries} -T {timeout} -q --output-document - '{cgi_url}'"
    out = subprocess.check_output(shlex.split(cmd))
    out_data = out.decode('utf-8')
    data = json.loads(out_data)
    if "Head" not in data or "ErrorCode" not in data["Head"]:
        raise ValueError(f"CGI HTTP response missing Head or ErrorCode field. Request {cgi_url} "
                         "failed.")
    if int(data["Head"]["ErrorCode"]) != 0:
        raise ValueError(f'Sent CGI request {cgi_url}. Got ErrorCode {data["Head"]["ErrorCode"]} '
                         f'with message \"{data["Head"]["Message"]}\"')
    if action == CgiAction.GET:
        return data["Body"]
    return None


def get_cgi(obj: str, key="", **kwargs):
    """Sends a get CGI action with given args."""
    return send_cgi(CgiAction.GET, obj, key, **kwargs)


def set_cgi(obj: str, key="", value="", **kwargs):
    """Sends a set CGI action with given args."""
    return send_cgi(CgiAction.SET, obj, key, value, **kwargs)


class HesaiLidar:

    def __init__(self, ip="192.168.1.201") -> None:
        self.ip = ip

    def send_cgi(self, action: CgiAction, obj: str, key="", value="", **kwargs):
        return send_cgi(action, obj, key, value, ip=self.ip, **kwargs)

    def get_cgi(self, obj: str, key="", **kwargs):
        return self.send_cgi(CgiAction.GET, obj, key, **kwargs)

    def set_cgi(self, obj: str, key="", value="", **kwargs):
        return self.send_cgi(CgiAction.SET, obj, key, value, **kwargs)

    def get_lidar_config(self) -> dict:
        """Gets Hesai lidar lidar config.

        Look at page 9 in HTTP protocol manual for "Body" return.
        """
        return self.get_cgi("lidar_config")

    def get_ptp_configuration(self) -> dict:
        """Gets Hesai lidar PTP configuration.
        """
        return json.loads(self.get_lidar_config()["PTPConfig"])

    def get_ptp_profile(self) -> HesaiPtpProfile:
        """Gets Hesai lidar PTP profile."""
        return HesaiPtpProfile(int(self.get_lidar_config()["PTPProfile"]))

    def get_ptp_status(self):
        # Split the PTPStatus string into status and offset
        out = self.get_lidar_config()['PTPStatus']
        if "offset" in out:
            status, offset_str = out.split(' (offset: ')
            offset = offset_str.rstrip(' ns)')    # Remove trailing ' ns)'
        else:
            status = out
            offset = -1
        return HesaiPtpStatus(status, offset)

    def get_ethernet_all(self) -> dict:
        """Gets Hesai lidar ethernet settings.

        Look at page 11 in HTTP protocol manual for "Body" return.
        """
        return self.get_cgi("ethernet_all")

    def get_device_info(self) -> dict:
        """Gets Hesai lidar device info.

        Look at page 7 in HTTP protocol manual for "Body" return.
        """
        return self.get_cgi("device_info")

    def get_serial_number(self) -> str:
        """Gets Hesai lidar serial number."""
        return self.get_device_info()["SN"]

    def get_model_type(self) -> HesaiModelType:
        """Gets Hesai model type."""
        device_info = self.get_device_info()
        prod_name = device_info["ProdName"]
        laser_num = int(device_info["LaserNum"])
        if prod_name == "PandarXT":
            if laser_num == 32:
                return HesaiModelType.PANDARXT32
        raise NotImplementedError(
            f"Hesai with ProdName \"{prod_name}\" and LaserNum \"{laser_num}\" "
            "not yet supported.")

    def get_return_mode(self) -> HesaiReturnMode:
        """Gets Hesai lidar return mode."""
        mode = int(self.get_cgi("lidar_data", "lidar_mode")["lidar_mode"])
        if not mode in HesaiReturnMode:
            raise ValueError(f"Returned mode {mode} not part of return mode enum.")
        return HesaiReturnMode(mode)

    def get_ptp_lock_offset(self):
        return self.get_cgi("PTP_lock_offset")

    def set_ip_desnation(self, ipv4: str, port: int):
        """Sets Hesai lidar IP destination."""
        conf = {
            "IPv4": ipv4,
            "Port": port,
            "GpsPort": 10110,
        }
        return self.set_cgi("lidar", "ip_disnation", conf)    # sic

    def set_return_mode(self, mode: HesaiReturnMode):
        """Sets Hesai lidar return mode."""
        return self.set_cgi("lidar_data", "lidar_mode", mode.value)

    def set_clock_source(self, source=HesaiClockSource.GPS):
        """Sends a set clock source CGI request to Hesai lidar."""
        return self.set_cgi("lidar", "clock_source", source.value)

    def set_control_port_ip(self, ipv4: str):
        """Sends a set control IPv4 CGI request to Hesai lidar."""
        base_ip = ipv4[:ipv4.rindex('.')]
        gateway = f"{base_ip}.1"
        conf = {
            "DHCP": 0,
            "IPv4": ipv4,
            "Mask": "255.255.255.0",
            "Gateway": gateway,
            "VlanFlag": 0,
            "VlanID": 1
        }
        # Ignore CalledProcessError since its difficult to confirm the command worked. It changes
        # the IP the cgi request is interfacing with so it will lose connection and not get a
        # response.
        try:
            self.set_cgi("control_port", "ip", conf, timeout=1)
        except subprocess.CalledProcessError:
            pass

    def set_ptp_configuration(self,
                              profile: HesaiPtpProfile = None,
                              domain: int = None,
                              network: HesaiPtpNetwork = None,
                              log_announce_interval: int = None,
                              log_sync_interval: int = None,
                              log_min_delay_req_interval: int = None):
        """Sets Hesai lidar PTP configuration."""
        conf = self.get_ptp_configuration()    # Use previous PTP config values as defaults
        conf["Profile"] = self.get_ptp_profile().value
        if profile:
            conf["Profile"] = profile.value
        if domain:
            conf["Domain"] = domain
        if network:
            conf["Network"] = network.value
        if log_announce_interval:
            conf["LogAnnounceInterval"] = log_announce_interval
        if log_sync_interval:
            conf["LogSyncInterval"] = log_sync_interval
        if log_min_delay_req_interval:
            conf["LogMinDelayReqInterval"] = log_min_delay_req_interval
        return self.set_cgi("lidar", "ptp_configuration", conf)

    def set_ptp_lock_offset(self, offset: int):
        """Sets the PTP lock offset to a value in microseconds between 1-100us."""
        return self.set_cgi("PTP_lock_offset", str(offset))
