#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
sudo rm /var/lib/nvpmodel/status 2>/dev/null                                                  # clear old mode config
sudo sed -i -e 's/^< PM_CONFIG DEFAULT=[0-9]\+ >/< PM_CONFIG DEFAULT=2 >/' /etc/nvpmodel.conf # change default power mode
