/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <string.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include "cxxopts.hpp"
#include "yaml-cpp/yaml.h"

#include "hawk_eeprom.h"
#include "hawk_utils.h"

int set_poly_yaml(const YAML::Node& yaml, polynomial_lens_distortion_coeff& poly) {
  poly.radial_coeff_count = yaml["radial_coeff_count"].as<unsigned int>();
  poly.k[0] = yaml["k"][0].as<float>();
  poly.k[1] = yaml["k"][1].as<float>();
  poly.k[2] = yaml["k"][2].as<float>();
  poly.k[3] = yaml["k"][3].as<float>();
  poly.k[4] = yaml["k"][4].as<float>();
  poly.k[5] = yaml["k"][5].as<float>();
  poly.tangential_coeff_count = yaml["tangential_coeff_count"].as<unsigned int>();
  poly.p[0] = yaml["p"][0].as<float>();
  poly.p[1] = yaml["p"][1].as<float>();
  return 0;
}

int set_fisheye_yaml(const YAML::Node& yaml, fisheye_lens_distortion_coeff& fisheye) {
  fisheye.coeff_count = yaml["coeff_count"].as<unsigned int>();
  fisheye.k[0] = yaml["k"][0].as<float>();
  fisheye.k[1] = yaml["k"][1].as<float>();
  fisheye.k[2] = yaml["k"][2].as<float>();
  fisheye.k[3] = yaml["k"][3].as<float>();
  fisheye.k[4] = yaml["k"][4].as<float>();
  fisheye.k[5] = yaml["k"][5].as<float>();
  fisheye.mapping_type = yaml["mapping_type"].as<uint32_t>();
  return 0;
}

int set_cam_intr_yaml(const YAML::Node& yaml, camera_intrinsics& intr) {
  intr.width = yaml["width"].as<unsigned int>();
  intr.height = yaml["height"].as<unsigned int>();
  intr.fx = yaml["fx"].as<float>();
  intr.fy = yaml["fy"].as<float>();
  intr.skew = yaml["skew"].as<float>();
  intr.cx = yaml["cx"].as<float>();
  intr.cy = yaml["cy"].as<float>();
  intr.distortion_type = yaml["distortion_type"].as<unsigned int>();
  if (intr.distortion_type == 0) {
    set_poly_yaml(yaml["dist_coeff"]["poly"], intr.dist_coeff.poly);
  } else if (intr.distortion_type == 1) {
    set_fisheye_yaml(yaml["dist_coeff"]["fisheye"], intr.dist_coeff.fisheye);
  }
  return 0;
}

int set_extr_yaml(const YAML::Node& yaml, camera_extrinsics& extr) {
  extr.rx = yaml["rx"].as<float>();
  extr.ry = yaml["ry"].as<float>();
  extr.rz = yaml["rz"].as<float>();
  extr.tx = yaml["tx"].as<float>();
  extr.ty = yaml["ty"].as<float>();
  extr.tz = yaml["tz"].as<float>();
  return 0;
}

int set_imu_yaml(const YAML::Node& yaml, imu_params_v1& imu) {
  int ret = 0;
  imu.linear_acceleration_bias[0] = yaml["linear_acceleration_bias"][0].as<float>();
  imu.linear_acceleration_bias[1] = yaml["linear_acceleration_bias"][1].as<float>();
  imu.linear_acceleration_bias[2] = yaml["linear_acceleration_bias"][2].as<float>();
  imu.angular_velocity_bias[0] = yaml["angular_velocity_bias"][0].as<float>();
  imu.angular_velocity_bias[1] = yaml["angular_velocity_bias"][1].as<float>();
  imu.angular_velocity_bias[2] = yaml["angular_velocity_bias"][2].as<float>();
  imu.gravity_acceleration[0] = yaml["gravity_acceleration"][0].as<float>();
  imu.gravity_acceleration[1] = yaml["gravity_acceleration"][1].as<float>();
  imu.gravity_acceleration[2] = yaml["gravity_acceleration"][2].as<float>();
  ret = set_extr_yaml(yaml["extr"], imu.extr);
  return ret;
}

int set_nm_yaml(const YAML::Node& yaml, imu_params_noise_m& nm) {
  nm.update_rate = yaml["update_rate"].as<float>();
  nm.linear_acceleration_noise_density = yaml["linear_acceleration_noise_density"].as<float>();
  nm.linear_acceleration_random_walk = yaml["linear_acceleration_random_walk"].as<float>();
  nm.angular_velocity_noise_density = yaml["angular_velocity_noise_density"].as<float>();
  nm.angular_velocity_random_walk = yaml["angular_velocity_random_walk"].as<float>();
  return 0;
}

int update_from_yaml_file(hawk_eeprom_struct& liee, const YAML::Node& yaml) {
  liee.version = yaml["version"].as<unsigned int>();
  liee.factory_data = yaml["factory_data"].as<unsigned int>();

  set_cam_intr_yaml(yaml["left_cam_intr"], liee.left_cam_intr);
  set_cam_intr_yaml(yaml["right_cam_intr"], liee.right_cam_intr);
  set_extr_yaml(yaml["cam_extr"], liee.cam_extr);

  liee.imu_present = yaml["imu_present"].as<unsigned char>();
  set_imu_yaml(yaml["imu"], liee.imu);
  const char* k = NULL;
  std::string sn = yaml["serial_number"].as<std::string>();
  k = sn.c_str();
  for (int i = 0; i < 8; i++) {
    liee.serial_number[i] = k[i];
  }
  set_nm_yaml(yaml["nm"], liee.nm);

  return 0;
}

int write_register_byte(
    const int fd, const u8 addr, const u8 offset_addr, const u8 val, u8* ret_val) {
  struct i2c_msg i2c_msg = {0};
  struct i2c_rdwr_ioctl_data i2cdev_data = {0};
  struct i2c_msg msgs[1] = {0};
  u8 buf[3] = {0x00};
  u8 buf_r[3] = {0x00};
  int ret = 0;

  buf[0] = offset_addr;
  buf[1] = val;

  msgs[0].addr = addr;
  msgs[0].flags = 0;
  msgs[0].len = 2;
  msgs[0].buf = buf;
  i2cdev_data.nmsgs = 1;
  i2cdev_data.msgs = msgs;

  ret = ioctl(fd, I2C_RDWR, &i2cdev_data);
  if (ret < 0) {
    printf("ioctl failed while writing\n");
    return ret;
  }

  (*ret_val) = buf_r[0];
  return 0;
}

int eeprom_write(const int fd, const uint addr, const uint offset, unsigned char* buf, uint len) {
  int ret = 0;
  if (fd < 0) {
    printf("fd is not open\n");
    return -1;
  }
  usleep(50000);
  for (int i = 0; i < len; i++) {
    u8 ret_val;
    ret = write_register_byte(fd, addr + (i / 256), offset + (i & 0xff), buf[i], &ret_val);
    if (ret < 0) {
      printf("couldn't write byte\n");
      return ret;
    }
    usleep(10000);
  }
  return 0;
}

int main(int argc, char** argv) {
  cxxopts::Options options(
      "update_eeprom",
      "Updates eeprom contents with yaml file assuming its from a Leopard Imaging HAWK camera.");
  options.positional_help("<file> <i2c-bus>");
  options.add_options()("file", "The yaml file to load", cxxopts::value<std::string>())(
      "i2c-bus", "Integer for i2c bus to read. GMSL e3653 options are {30,31}.",
      cxxopts::value<int>())(
      "n,dry-run", "Doesn't write to the eeprom.", cxxopts::value<bool>()->default_value("false"))(
      "v,verbose", "Verbose output. Prints raw eeprom binary.",
      cxxopts::value<bool>()->default_value("false"))("h,help", "Print usage");
  options.parse_positional({"file", "i2c-bus"});
  auto result = options.parse(argc, argv);
  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    exit(0);
  }
  bool verbose = result["verbose"].as<bool>();
  bool dry_run = result["dry-run"].as<bool>();
  auto file = result["file"].as<std::string>();
  auto i2c_bus = result["i2c-bus"].as<int>();

  if (verbose) {
    spdlog::set_level(spdlog::level::debug);
  }

  int fd;
  if (get_i2c_fd(fd, i2c_bus, O_RDWR)) {
    return -1;
  }
  hawk_eeprom_struct liee;
  eeprom_read(fd, EEPROM_ADDRESS, 0x00, reinterpret_cast<u_char*>(&liee), sizeof(liee));
  YAML::Node yaml = YAML::LoadFile(file);
  spdlog::debug("----------------YAML EEPROM------------------\n{}", yaml);
  update_from_yaml_file(liee, yaml);
  if (verbose || dry_run) {
    unsigned char* buf = reinterpret_cast<u_char*>(&liee);
    spdlog::info("----------------RAW EEPROM-------------------");
    for (int i = 0; i < sizeof(liee); i++) {
      printf("%x ", buf[i]);
    }
    printf("\n");
  }
  if (!dry_run) {
    eeprom_write(fd, EEPROM_ADDRESS, 0x00, reinterpret_cast<u_char*>(&liee), sizeof(liee));
  }
  close(fd);
}
