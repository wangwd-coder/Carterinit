#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

from dataclasses import dataclass
from enum import auto, Enum
from typing import Mapping

ROBOT_NAME_MAP = {
    "carter": "CR",
    "recording-rig": "RR",
    "nvidia-internal": "NI",    # necessary for platforms that aren't robots
}
ROBOT_SN_LENGTHS_MAP = {"wmi": 3, "version": 6, "model": 2, "index": 6}
ROBOT_SN_MAX_LENGTH = sum(ROBOT_SN_LENGTHS_MAP.values())


@dataclass
class SensorMetadata:
    serial_number: str


@dataclass
class TegraMetadta:
    type: str
    serial_number: str


@dataclass
class JetpackMetadata:
    version: str


@dataclass
class TegraPlatform:
    tegra: TegraMetadta
    jetpack: JetpackMetadata


@dataclass
class NovaMetadata:
    version: str
    model: str
    model_version: str
    serial_number: str
    sensors: Mapping[str, SensorMetadata]
    platform: TegraPlatform
