#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# This script configures calibration files
set -e
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

cal_dir="/etc/nova/calibration"
cal_file="$cal_dir/isaac_calibration.json"
if [ ! -d $cal_dir ]; then
  mkdir $cal_dir
fi
if [ -f $cal_file ]; then
  exit 0
fi

case "$NOVA_ROBOT_ID" in
  "CR")
    tmp_cal="$SCRIPT_DIR/carter-v$NOVA_ROBOT_MAJORV.$NOVA_ROBOT_MINORV.json"
    if [ ! -f $tmp_cal ]; then
      echoerr "$tmp_cal is not a file"
      exit 1
    fi
    safe_cp $tmp_cal $cal_file
    ;;
  "RR")
    safe_cp $SCRIPT_DIR/recording-rig-128-v0.2.json $cal_file
    ;;
  *)
    echoerr "$id is not a valid identifier"
    exit 1
    ;;
esac
chmod 666 $cal_file
python3 $SCRIPT_DIR/update_calibration_file.py -f $cal_file
