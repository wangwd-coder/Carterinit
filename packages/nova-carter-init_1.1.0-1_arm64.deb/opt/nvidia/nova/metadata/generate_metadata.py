#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

# NOTE: command to generate metadata without writing
# python generate_metadata.py --dry-run

from argparse import ArgumentParser
import dataclasses
import json
import re

from nova_init.metadata.constants import (TegraMetadta, JetpackMetadata, TegraPlatform,
                                          SensorMetadata, NovaMetadata)
from nova_init.utils import (NovaChannels)
from nova_init.metadata.utils import (get_serial_number, get_sn_parts, get_jetpack_version,
                                      get_tegra_type, get_tegra_sn, get_hawk_sn, get_hesai_sn,
                                      get_realsense_sn, get_segway_drivetrain_sn,
                                      get_model_from_map, get_rplidar_sn, get_owl_sn)

VERSION = "0.0.1"


def get_platform():
    '''Gets platform for JSON.'''
    tegra = TegraMetadta(get_tegra_type(), get_tegra_sn())
    jetpack = JetpackMetadata(get_jetpack_version())
    return TegraPlatform(tegra, jetpack)


def get_sensors(serial_number: str):
    '''Gets a sensors map.
    '''
    model, model_version, index = get_sn_parts(serial_number)
    pre_sensors = {}    # map from enums to sensor value before string conversion
    benchtop_use = False
    # NVIDIA internal assumes first two characters in index are the model, allows for benchtops
    if model == "nvidia-internal":
        benchtop_use = True
        abbr = index[:2]
        model = get_model_from_map(abbr)
    # Get all sensors associated with model
    if model == "carter":
        if re.match(r"2.3.\d{1,2}", model_version):
            pre_sensors = {
                NovaChannels.kFrontStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kFrontStereoCamera)),
                NovaChannels.kRearStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kRearStereoCamera)),
                NovaChannels.kFrontDepthCamera:
                SensorMetadata(get_realsense_sn(0)),
                NovaChannels.kRearDepthCamera:
                SensorMetadata(get_realsense_sn(1)),
                NovaChannels.kFront3dLidar:
                SensorMetadata(get_hesai_sn("192.168.1.201")),
                NovaChannels.kFrontStereoImu:
                SensorMetadata(get_hawk_sn(NovaChannels.kFrontStereoCamera)),
            }
            if not benchtop_use:
                pre_sensors.update(
                    {NovaChannels.kDrivetrain: SensorMetadata(get_segway_drivetrain_sn())})
        elif re.match(r"2.4.\d{1,2}", model_version):
            pre_sensors = {
                NovaChannels.kFrontStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kFrontStereoCamera)),
                NovaChannels.kRearStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kRearStereoCamera)),
                NovaChannels.kLeftStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kLeftStereoCamera)),
                NovaChannels.kRightStereoCamera:
                SensorMetadata(get_hawk_sn(NovaChannels.kRightStereoCamera)),
                NovaChannels.kFrontFisheyeCamera:
                SensorMetadata(get_owl_sn(NovaChannels.kFrontFisheyeCamera)),
                NovaChannels.kRearFisheyeCamera:
                SensorMetadata(get_owl_sn(NovaChannels.kRearFisheyeCamera)),
                NovaChannels.kLeftFisheyeCamera:
                SensorMetadata(get_owl_sn(NovaChannels.kLeftFisheyeCamera)),
                NovaChannels.kRightFisheyeCamera:
                SensorMetadata(get_owl_sn(NovaChannels.kRightFisheyeCamera)),
                NovaChannels.kFront3dLidar:
                SensorMetadata(get_hesai_sn("192.168.1.201")),
                NovaChannels.kFrontStereoImu:
                SensorMetadata(get_hawk_sn(NovaChannels.kFrontStereoCamera)),
                NovaChannels.kFront2dLidar:
                SensorMetadata(get_rplidar_sn("192.168.1.2")),
                NovaChannels.kBack2dLidar:
                SensorMetadata(get_rplidar_sn("192.168.1.3")),
                NovaChannels.kDrivetrain:
                SensorMetadata(get_segway_drivetrain_sn()),
            }
            if not benchtop_use:
                pre_sensors.update(
                    {NovaChannels.kDrivetrain: SensorMetadata(get_segway_drivetrain_sn())})
        else:
            raise ValueError(
                f"model {model} and version {model_version} does not have its metadata configured")
    elif model == "recording-rig":
        pre_sensors = {
            NovaChannels.kFrontStereoCamera: SensorMetadata(get_hawk_sn(0)),
            NovaChannels.kFront3dLidar: SensorMetadata(get_hesai_sn("192.168.1.201")),
            NovaChannels.kFrontStereoImu: SensorMetadata(get_hawk_sn(0)),
        }
    else:
        raise ValueError(f"model {model} not valid")
    # Convert to readable dictionary
    sensors = {}
    for k, v in pre_sensors.items():
        sensors[k.snake_name] = v
    return sensors


# Convert dataclass to json
# https://stackoverflow.com/a/51286749
class EnhancedJSONEncoder(json.JSONEncoder):

    def default(self, o):
        if dataclasses.is_dataclass(o):
            return dataclasses.asdict(o)
        return super().default(o)


def generate_metadata(args, file_path: str):
    '''Generates metadata using system tools and libraries.
    '''
    serial_number = get_serial_number()
    model, model_version, _ = get_sn_parts(serial_number)
    metadata = NovaMetadata(VERSION, model, model_version, serial_number,
                            get_sensors(serial_number), get_platform())
    json_data = json.dumps(metadata, cls=EnhancedJSONEncoder, indent=4)
    if args.dry_run:
        print(json_data)
    else:
        f = open(file_path, "w")
        f.write(json_data)
        f.close()


def main():
    parser = ArgumentParser()
    parser.add_argument("-o",
                        "--output",
                        default="/etc/nova/metadata.json",
                        type=str,
                        help="Output path for metadata JSON.")
    parser.add_argument("-n",
                        "--dry-run",
                        action="store_true",
                        help="Generates metadata and outputs results without writing.")
    args = parser.parse_args()
    generate_metadata(args, args.output)


if __name__ == "__main__":
    main()
