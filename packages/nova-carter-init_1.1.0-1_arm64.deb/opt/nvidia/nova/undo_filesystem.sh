#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Undoes filesystem changes
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/exit.sh
source $SCRIPT_DIR/utils.sh

if [[ ! -f "$NOVA_ADD_LIST" && ! -f "$NOVA_RM_LIST" ]]; then
  echowarn "$NOVA_ADD_LIST and $NOVA_RM_LIST do not exist, assuming no files were added/removed during install skipping..."
  exit 0
fi

# NOTE: ORDER MATTERS, restoring rm files must happen before added files since rm adds its history
# file
# Restore backups of all removed files first
if [[ -f "$NOVA_RM_LIST" ]]; then
  while IFS= read -r file; do
    backup="$file$NOVA_DEFAULT_SUFFIX"
    if [[ -f "$backup" ]]; then
      restore_backup "$backup"
    else
      echowarn "backup file for removed file $file does not exist"
    fi
  done <"$NOVA_RM_LIST"
else
  echowarn "no files were removed during install, $NOVA_RM_LIST does not exist, continuing..."
fi

# Restore backups of added files
if [[ -f "$NOVA_ADD_LIST" ]]; then
  while IFS= read -r file; do
    backup="$file$NOVA_DEFAULT_SUFFIX"
    if [[ ! -f "$file" ]]; then
      echowarn "added file $file does not exist anymore, continuing..."
    elif [[ -f "$backup" ]]; then
      restore_backup "$backup"
    else
      rm "$file"
    fi
  done <"$NOVA_ADD_LIST"
else
  echowarn "no files were added during install, $NOVA_ADD_LIST does not exist, continuing..."
fi
