#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Updates the firmware for segway
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
# Run undo and setup to make sure files are backed up appropriately
sudo $SCRIPT_DIR/undo_segway.sh
sudo $SCRIPT_DIR/setup_segway.sh
# Update firmware through CAN
sudo $SCRIPT_DIR/lib/ctrl_arm64-v8a c -iap central
sudo $SCRIPT_DIR/lib/ctrl_arm64-v8a c -iap motor
