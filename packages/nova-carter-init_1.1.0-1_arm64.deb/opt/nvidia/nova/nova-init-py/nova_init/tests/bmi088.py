#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

import subprocess
import os
import signal
import time
import pytest
from dataclasses import dataclass

from nova_init.tests.filesystem import get_bmi_device_pairs

IIO_GENERIC_PATH = "/opt/nvidia/nova/tools/hawk/iio_generic_buffer"
DEFAULT_NUM_SAMPLES = 250
NOMINAL_FREQ = 100.0

TOLERANCE_HZ = 5.0


@dataclass
class bmiImuIdxs:
    accel_iio_index: str
    gyro_iio_index: str


# Apply python fixture outside. Necessary to choose custom input params.
# Example: setup_bmi = pytest.fixture(setup_bmi, scope='class', params=[(69), (68)])
def setup_bmi(request):
    bmi_id = request.param
    all_imus = get_bmi_device_pairs()
    assert bmi_id in all_imus, f"No Imu found with id: {bmi_id}"
    accel_iio_index = all_imus[bmi_id][0]
    gyro_iio_index = all_imus[bmi_id][1]

    bmi = bmiImuIdxs(accel_iio_index, gyro_iio_index)
    yield bmi

    set_freq(bmi, accel_iio_index, NOMINAL_FREQ)
    set_freq(bmi, gyro_iio_index, NOMINAL_FREQ)


def set_freq(setup_bmi, iio_index: int, freq: float):
    """Set the frequency for device specified by iio_index to freq

    Args:
        iio_index (int): index of the device to use
        freq(float): the frequency to set, e.g. 100.0
    Returns:
        None
    """
    bmi = setup_bmi
    assert iio_index in {bmi.accel_iio_index, bmi.gyro_iio_index}
    if iio_index == bmi.accel_iio_index:
        freq_str = f"/sys/bus/iio/devices/iio:device{bmi.accel_iio_index}/in_accel_sampling_frequency"
    else:
        freq_str = f"/sys/bus/iio/devices/iio:device{bmi.gyro_iio_index}/in_anglvel_sampling_frequency"

    subprocess.run(["echo", str(freq)], stdout=open(freq_str, "w"))
    res = subprocess.run(["cat", freq_str], stdout=subprocess.PIPE, text=True)
    assert float(res.stdout) == float(
        freq), f"Could not set freq for device {iio_index} to {freq}, got {float(res.stdout)} "


def check_freq(setup_bmi,
               iio_index: int,
               target_freq: float,
               tolerance: float = 5.0,
               num_samples: int = DEFAULT_NUM_SAMPLES):
    """Test that the frequency of device {iio_index} is within tolerance of target_freq

    Args:
        iio_index (int): index of the device to use
        target_freq(float): The expected frequency
        tolerance(float):  Tolerance for deviation from target frequency in Hz
    Returns:
        None
    """
    bmi = setup_bmi
    iio_invoke = [IIO_GENERIC_PATH, "-A", "-g", "-c", str(num_samples), "-N", str(iio_index)]

    start_time = time.time()
    result = subprocess.run(iio_invoke, stdout=subprocess.PIPE, universal_newlines=True)
    end_time = time.time()

    est_freq = num_samples / (end_time - start_time)
    assert target_freq - tolerance < est_freq < target_freq + tolerance, \
        f"Expected frequency for device {iio_index} was {target_freq}Hz, but measured {est_freq}Hz"


#@pytest.mark.bmi
class TestBmi088Imu:

    def test_nominal_freq(self, setup_bmi):
        bmi = setup_bmi
        set_freq(bmi, bmi.accel_iio_index, NOMINAL_FREQ)
        check_freq(bmi, bmi.accel_iio_index, NOMINAL_FREQ)

        set_freq(bmi, bmi.gyro_iio_index, NOMINAL_FREQ)
        check_freq(bmi, bmi.gyro_iio_index, NOMINAL_FREQ)

    def test_simultanous_freq(self, setup_bmi):
        bmi = setup_bmi
        ACCEL_FREQ = 12.5
        GYRO_FREQ = 200.0

        set_freq(bmi, bmi.accel_iio_index, ACCEL_FREQ)
        set_freq(bmi, bmi.gyro_iio_index, GYRO_FREQ)

        gyro_invoke = [IIO_GENERIC_PATH, "-A", "-g", "-c", str(-1), "-N", str(bmi.gyro_iio_index)]
        process = subprocess.Popen(gyro_invoke, stdout=subprocess.PIPE, universal_newlines=True)
        check_freq(bmi, bmi.accel_iio_index, ACCEL_FREQ, tolerance=2.0, num_samples=50)
        os.kill(process.pid, signal.SIGINT)
