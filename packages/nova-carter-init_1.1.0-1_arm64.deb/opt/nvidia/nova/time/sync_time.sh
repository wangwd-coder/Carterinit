#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Synchronizes time using NTP or RTC if no internet
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

# Force an ntp sync
if sudo timeout 90 ntpd -gq; then
  # Syncs RTC time to local
  sudo hwclock -w
  echoinfo "synced RTC to local time"
else # Failed NTP sync
  # Syncs local time to RTC
  sudo hwclock -s
  echoinfo "no internet, synced local time to RTC"
fi

# Set the PHC clock to systime
sudo phc_ctl eth0 -- set
