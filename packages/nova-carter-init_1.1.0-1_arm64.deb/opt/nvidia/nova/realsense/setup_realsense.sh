#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Installs the realsense library to get serial numbers
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
RELEASE=2.54.1
RELEASE_FILE=v$RELEASE.zip

librealsense_dir_="$SCRIPT_DIR/librealsense-$RELEASE"

# Exit early if librealsense is already built with SN command
if command -v rs-enumerate-devices &>/dev/null && [ ! -d $librealsense_dir_ ]; then
  echowarn "librealsense is already built outside of nova-init, not building"
  exit 0
fi
# Build librealsense
cd $SCRIPT_DIR
if [ ! -d "$librealsense_dir_" ]; then
  wget https://github.com/IntelRealSense/librealsense/archive/refs/tags/$RELEASE_FILE
  unzip -q -o ./$RELEASE_FILE -d .
  rm $RELEASE_FILE
else
  echowarn "found librealsense at \"$librealsense_dir_\", delete this folder with " \
    "\"$SCRIPT_DIR/undo_realsense.sh\" if you want to reinstall librealsense during nova-init's " \
    "next install"
fi
cd $librealsense_dir_
if [ ! -d build ]; then
  mkdir build
fi
cd build
cmake ../ -DFORCE_RSUSB_BACKEND=true -DCMAKE_BUILD_TYPE=release -DBUILD_EXAMPLES=false \
  -DBUILD_GRAPHICAL_EXAMPLES=false -DIMPORT_DEPTH_CAM_FW=false -DBUILD_EASYLOGGINGPP=true \
  -DBUILD_WITH_TM2=false -DBUILD_WITH_STATIC_CRT=false -DBUILD_GLSL_EXTENSIONS=false
make -j$(nproc)
sudo make install
