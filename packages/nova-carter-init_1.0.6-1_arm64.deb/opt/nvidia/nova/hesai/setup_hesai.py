#!/usr/bin/python3
##############################################################################
# Copyright (c) 2022, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
from argparse import ArgumentParser
from nova_init.hesai.hesai_utils import (HesaiReturnMode, HesaiPtpNetwork, HesaiClockSource,
                                         HesaiModelType, HesaiLidar)
import subprocess


def setup_hesai(ipv4, new_ipv4):
    hesai = HesaiLidar(ipv4)
    model_type = hesai.get_model_type()
    if model_type == HesaiModelType.PANDARXT32:
        hesai.set_return_mode(HesaiReturnMode.FIRST_STRONGEST)
        hesai.set_clock_source(HesaiClockSource.PTP)
        hesai.set_ptp_configuration(network=HesaiPtpNetwork.L2)
        hesai.set_ip_desnation("255.255.255.255", 2368)
        hesai.set_ptp_lock_offset(5)
        # Setting IP must be last
        if new_ipv4 != "":
            hesai.set_control_port_ip(new_ipv4)
    else:
        raise NotImplementedError(f"Hesai `model_type` {model_type.name} not supported.")


def main():
    parser = ArgumentParser()
    default_ip = "192.168.1.201"
    parser.add_argument("--ipv4", type=str, default=default_ip, help=f"IPv4 address for hesai.")
    parser.add_argument("--new-ipv4", type=str, default="", help=f"New IPv4 address for hesai.")
    args = parser.parse_args()
    setup_hesai(args.ipv4, args.new_ipv4)


if __name__ == "__main__":
    main()
