#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

from dataclasses import dataclass
from enum import auto, Enum
from typing import Mapping

ROBOT_NAME_MAP = {
    "carter": "CR",
    "recording-rig": "RR",
    "nvidia-internal": "NI",    # necessary for platforms that aren't robots
}
ROBOT_SN_LENGTHS_MAP = {"wmi": 3, "version": 6, "model": 2, "index": 6}
ROBOT_SN_MAX_LENGTH = sum(ROBOT_SN_LENGTHS_MAP.values())


def camel_to_snake(str: str):
    """Converts camel case string to snake case"""
    res = str[0].lower()
    for c in str[1:]:
        if c.isupper() or c.isdigit():
            res += '_'
            res += c.lower()
        else:
            res += c
    return ''.join(res)


#!NOTE: CHANGES TO THE DATACLASSES HERE MUST BE REFLECTED IN NVIDIA ISAAC REPO
class NovaChannels(Enum):
    kError = -1
    kFrontStereoCamera = 0
    kRearStereoCamera = auto()
    kLeftStereoCamera = auto()
    kRightStereoCamera = auto()
    kFrontDepthCamera = auto()
    kRearDepthCamera = auto()
    kFront3dLidar = auto()
    kFrontStereoImu = auto()
    kRearStereoImu = auto()
    kDrivetrain = auto()
    kChassisImu = auto()
    kFront2dLidar = auto()
    kBack2dLidar = auto()

    @property
    def snake_name(self):
        return camel_to_snake(self.name[1:])


@dataclass
class SensorMetadata:
    serial_number: str


@dataclass
class TegraMetadta:
    type: str
    serial_number: str


@dataclass
class JetpackMetadata:
    version: str


@dataclass
class TegraPlatform:
    tegra: TegraMetadta
    jetpack: JetpackMetadata


@dataclass
class NovaMetadata:
    version: str
    model: str
    model_version: str
    serial_number: str
    sensors: Mapping[str, SensorMetadata]
    platform: TegraPlatform
