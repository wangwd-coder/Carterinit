#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Sets up ptp
# TODO(bmchale): add safe way to backup when doing sed changes
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh
ptp_srv_file=/lib/systemd/system/ptp4l.service
backup_ext=".bak"
# Don't create backup if it already exists
if [ -f $ptp_srv_file$backup_ext ]; then
  backup_ext=""
fi
# Need to make ptp4l wait for /dev/ptp0 on boot or else ptp4l will crash
sudo sed -i$backup_ext -e '/^Documentation=*/aRequires=dev-ptp0.device' $ptp_srv_file
sudo sed -i -e '/^Requires=*/aAfter=dev-ptp0.device' $ptp_srv_file

# Configure PTP
# https://tsn.readthedocs.io/timesync.html
sudo mkdir -p /etc/linuxptp 2>/dev/null
safe_cp $SCRIPT_DIR/ptp4l.conf /etc/linuxptp/ptp4l.conf

# Configure phc2sys
phc2sys_srv_file=/lib/systemd/system/phc2sys.service
backup_ext=".bak"
# Don't create backup if it already exists
if [ -f $phc2sys_srv_file$backup_ext ]; then
  backup_ext=""
fi

# The Hesai lidar, which is the PTP slave device we are using, uses UTC time
# phc2sys assumes all PTP time is IAT, and will offset all incoming timesstamps accordingly.
# This causes all sorts of problems, therefore we specify 0 as the offset from ptp time to UTC time.
sudo sed -i$backup_ext -e '/^ExecStart=*/s/$/ -O 0/' $phc2sys_srv_file

# https://tsn.readthedocs.io/timesync.html#synchronizing-the-system-clock
sudo pmc -u -b 0 -t 1 "SET GRANDMASTER_SETTINGS_NP clockClass 248 \
        clockAccuracy 0xfe offsetScaledLogVariance 0xffff \
        currentUtcOffset 37 leap61 0 leap59 0 currentUtcOffsetValid 1 \
        ptpTimescale 1 timeTraceable 1 frequencyTraceable 0 \
        timeSource 0xa0"
# Start services on boot
sudo systemctl enable ptp4l.service
sudo systemctl enable phc2sys.service
