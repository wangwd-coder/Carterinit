# NOVA etc

## serial_number

The serial_number file is generated during the initial setup procedure. It is made by running
`sudo /opt/nvidia/nova/metadata/generate_sn_file.py`. This file should not be modified because it
identifies the robot uniquely.

## metadata.json

The metadata.json file is generated on boot by the `nova-metadata-generator.service`. This service
calls the `/opt/nvidia/nova/metadata/generate_metadata.py`.
