#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
import subprocess
import re

LATCH_ADDRESS = 0x06810d70
PHC2SYS_NUM_SAMPLES = 5

MAX_OFFSET = 150
MAX_FREQ_ERROR = 150
PHC2SYS_PATTERN = r"phc offset\s+([+-]?\d+)\s+s2 freq\s+([+-]?\d+)"


def test_latch():
    ret = subprocess.run(["busybox", "devmem", "0x06810d70"],
                         stdout=subprocess.PIPE,
                         universal_newlines=True)

    val = ret.stdout
    assert int(val.rstrip("\n"), 16) == 1, "Latch value not set"
    return


def test_phc2sys_offsets():
    ret = subprocess.run(["systemctl", "status", "phc2sys.service"],
                         stdout=subprocess.PIPE,
                         universal_newlines=True)

    for printout in ret.stdout.split("\n")[-(PHC2SYS_NUM_SAMPLES + 1):-1]:
        match = re.search(PHC2SYS_PATTERN, printout)
        assert match, f"Could not find offset in phc2sys output: {printout}"
        offset = int(match.group(1))
        assert abs(offset) < MAX_OFFSET, \
            f"phc2sys reporting offset of {offset}, which is greater than max {MAX_OFFSET}"
    return


def test_phc2sys_frequency():
    ret = subprocess.run(["systemctl", "status", "phc2sys.service"],
                         stdout=subprocess.PIPE,
                         universal_newlines=True)

    for printout in ret.stdout.split("\n")[-(PHC2SYS_NUM_SAMPLES + 1):-1]:
        match = re.search(PHC2SYS_PATTERN, printout)
        assert match, f"Could not find frequence in phc2sys output: {printout}"
        freq_error = int(match.group(2))
        assert abs(freq_error) < MAX_FREQ_ERROR, \
            f"phc2sys reporting frequency error of {freq_error}, which is greater than max {MAX_FREQ_ERROR}"
    return
