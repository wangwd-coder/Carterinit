#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Undoes hesai changes
sudo sed -i -e '/^managed=/d' -e '/^\[ifupdown\]/amanaged=false' /etc/NetworkManager/NetworkManager.conf

# Remove UDP buffer increase
sudo sed -i -e "/^net.core.rmem_max=26214400/d" /etc/sysctl.conf
