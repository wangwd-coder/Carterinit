#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Sets up hesai
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

default_host="192.168.1.100"
dest_host="192.168.1.100"
default_ip="192.168.1.201"
dest_ip="192.168.1.201"
eth="eth0"
case "$NOVA_ROBOT_ID" in
  "CR")
    case "$NOVA_ROBOT_MAJORV-$NOVA_ROBOT_MINORV" in
      "2-4") ;;
      "2-3") ;;
      *)
        echoerr "$NOVA_ROBOT_PRE invalid"
        exit 1
        ;;
    esac
    ;;
  "RR") ;;
  *)
    echoerr "$NOVA_ROBOT_ID is not a valid identifier"
    exit 1
    ;;
esac

sudo sed -i.bak -e '/^managed=/d' -e '/^\[ifupdown\]/amanaged=true' /etc/NetworkManager/NetworkManager.conf

# Increase UDP receiver buffer size to 25MB
if ! grep -q net.core.rmem_max /etc/sysctl.conf; then
  echo "net.core.rmem_max=26214400" | sudo tee -a /etc/sysctl.conf >/dev/null
fi

# Reset hesai IP if it is found at another IP address
# Need to correct previous hesais that were set to 192.168.11.201
old_ip="192.168.11.201"
old_host="192.168.11.5"
reconfigure_ip $eth "$old_host"
if ping -w 1 -c 1 -I $eth $old_ip >/dev/null; then
  $NOVA_BASE_DIR/nova-init-py/venv/bin/python3 $NOVA_BASE_DIR/hesai/setup_hesai.py --ipv4 "$old_ip" --new-ipv4 "$dest_ip"
  reconfigure_ip $eth "$dest_host"
  if ! ping -w 1 -c 1 -I $eth "$dest_ip"; then
    echoerr "correcting hesai IP to $dest_ip from old ip $old_ip did not work"
    exit 1
  fi
fi

# Configure Hesai to new IP
reconfigure_ip $eth "$dest_host"
if ! ping -w 1 -c 1 -I $eth "$dest_ip" >/dev/null; then
  reconfigure_ip $eth "$default_host"
  if ! ping -w 1 -c 1 -I $eth $default_ip >/dev/null; then
    echowarn "can't reconfigure hesai ip since the default ip $default_ip is not reachable"
    reconfigure_ip $eth "$dest_host"
    exit 0
  fi
  $NOVA_BASE_DIR/nova-init-py/venv/bin/python3 $NOVA_BASE_DIR/hesai/setup_hesai.py --ipv4 "$default_ip" --new-ipv4 "$dest_ip"
  reconfigure_ip $eth "$dest_host"
  if ! ping -w 1 -c 1 -I $eth "$dest_ip"; then
    echoerr "hesai dest ip $dest_ip could not be set"
    exit 1
  fi
fi

# Need to manually set IP address before configuring Hesai, this sets it to the same value as
#  /etc/network/interfaces. Meant for use case where debian isn't installed already.
if ! ping -w 1 -c 1 -I $eth "$dest_ip" >/dev/null; then
  reconfigure_ip $eth "$dest_host"
fi
# Setup hesai web settings
if ping -w 1 -c 1 -I $eth "$dest_ip" >/dev/null; then
  $NOVA_BASE_DIR/nova-init-py/venv/bin/python3 $NOVA_BASE_DIR/hesai/setup_hesai.py --ipv4 "$dest_ip"
else
  echowarn "no hesai lidar is connected, continuing..."
fi
