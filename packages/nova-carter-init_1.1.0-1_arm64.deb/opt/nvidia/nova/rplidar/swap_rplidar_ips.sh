#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Swap the two RPLIDAR ips
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh
front_ip="192.168.1.2"
back_ip="192.168.1.3"
tmp_ip="192.168.1.4"
$SCRIPT_DIR/build/set_rplidar_ip $back_ip $tmp_ip
$SCRIPT_DIR/build/set_rplidar_ip $front_ip $back_ip
$SCRIPT_DIR/build/set_rplidar_ip $tmp_ip $front_ip
