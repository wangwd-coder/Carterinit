# nova_init

Package encapsulating necessary code for nova-init setup and tests.
