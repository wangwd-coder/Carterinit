#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Configures RPLIDARs if not configured
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

eth="eth0"
default_host="192.168.11.5"
default_ip="192.168.11.2"
dest_host="192.168.1.100"
dest_front="192.168.1.2"
dest_back="192.168.1.3"

rm -rf $SCRIPT_DIR/build
mkdir -p $SCRIPT_DIR/build
(cd $SCRIPT_DIR/build && cmake .. && make)

# Reset rplidars if they were setup to an old IP
old_host="$default_host"
old_front="$default_ip"
old_back="192.168.11.3"
reconfigure_ip $eth "$old_host"
if ping -w 1 -c 1 -I $eth $old_front >/dev/null && ping -w 1 -c 1 -I $eth $old_back >/dev/null; then
  echowarn "found old FRONT rplidar $old_front and old BACK rplidar $old_back, changing..."
  $SCRIPT_DIR/build/set_rplidar_ip $old_front $dest_front
  $SCRIPT_DIR/build/set_rplidar_ip $old_back $dest_back
  sleep 5 # give time for reset
fi

# Re-configure rplidars if they are not setup
reconfigure_ip $eth "$dest_host"
if ! ping -w 1 -c 1 -I $eth $dest_back >/dev/null || ! ping -w 1 -c 1 -I $eth $dest_front >/dev/null; then
  echowarn "rplidars are not configured yet"
  reconfigure_ip $eth "$default_host"
  if ! ping -w 1 -c 1 -I $eth $default_ip >/dev/null; then
    echoerr "default rplidar ip $default_ip not pingable"
    exit 1
  fi
  while true; do
    read -p "Would you like to re-configure the rplidars? This requires physically unplugging rplidars on the robot. Respond no if you don't have access. Install when you do."$'\n'"Response (y/n): " yn
    case $yn in
      [yY])
        read -p "Re-configuring. Please unplug the front rplidar at this time. Press enter once that's done." input
        timeout=45
        echo "Continuing. Please wait up to $timeout seconds."
        if ! ping -w $timeout -c 1 -I $eth $default_ip >/dev/null; then # network takes time re-configure, give it 30 seconds
          echoerr "could not ping an rplidar after unplugging, exiting..."
          exit 1
        fi
        echo "Re-configuring rplidar ip $default_ip to $dest_back"
        $SCRIPT_DIR/build/set_rplidar_ip $default_ip $dest_back
        read -p "Finished setting rplidar ip to $dest_back. Plug back in the front rplidar now. Press enter when it's done." input
        echo "Re-configuring front rplidar now..."
        if ! ping -w $timeout -c 1 -I $eth $default_ip >/dev/null; then
          echoerr "could not ping an rplidar after re-plugging, exiting..."
          exit 1
        fi
        $SCRIPT_DIR/build/set_rplidar_ip $default_ip $dest_front
        sleep 5 # give time to reset
        reconfigure_ip $eth "$dest_host"
        break
        ;;
      [nN])
        echowarn "not re-configuring rplidars at this time. $(echobold "RUN \`sudo $(realpath $0)\`") when you can physically unplug the rplidars on the robot."
        reconfigure_ip $eth "$dest_host"
        exit 0
        ;;
      *)
        echo "invalid response"
        ;;
    esac
  done
fi

# Confirm both rplidars are working
timeout=60
echo "Confirming rplidars are setup. Waiting for ${timeout}s..."
set +e
ping -w $timeout -c 1 -I $eth $dest_front >/dev/null &
front_pid=$!
ping -w $timeout -c 1 -I $eth $dest_back >/dev/null &
back_pid=$!
wait $front_pid
front_res=$?
wait $back_pid
back_res=$?
set -e
if [ ! $front_res -eq 0 ] || [ ! $back_res -eq 0 ]; then
  echoerr "one or both of the rplidars could not be pinged.$([ $front_res -eq 0 ] || echo " Front rplidar failed at $dest_front.")$([ $back_res -eq 0 ] || echo " Back rplidar failed at $dest_back.")"
  exit 1
fi
echoinfo "RPLIDARs setup! $(echobold "FRONT") rplidar is $(echobold "$dest_front"). $(echobold "BACK") rplidar is $(echobold "$dest_back")."
