#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Fixes RTC udev rules, enables ntp/phc/rtc services
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh
# NOTE: /etc/ is prioritized over /lib/ for udev rules with the same name
safe_cp /lib/udev/rules.d/50-udev-default.rules /etc/udev/rules.d/50-udev-default.rules
# https://forums.developer.nvidia.com/t/rtc-clock-battery-for-the-orin-dev-kit/220939/29?u=bmchale
sudo sed -i -e 's/^SUBSYSTEM=="rtc", ATTR{hctosys}=="[0-9]"/SUBSYSTEM=="rtc", ATTR{hctosys}=="0"/' \
  /etc/udev/rules.d/50-udev-default.rules

sudo systemctl disable ntp.service
