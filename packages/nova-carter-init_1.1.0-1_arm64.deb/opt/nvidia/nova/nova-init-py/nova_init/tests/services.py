#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
from enum import Enum, auto
import pytest
from pystemd.systemd1 import Unit
from nova_init.tests.utils import reduceidfn


class UnitFileState(Enum):
    ENABLED = 0
    DISABLED = auto()
    STATIC = auto()


class SubState(Enum):
    FAILED = 0
    DEAD = auto()
    RUNNING = auto()
    EXITED = auto()


SRV_SERVICE_PARAMS = [
    ("ptp4l", SubState.RUNNING, UnitFileState.ENABLED),
    ("phc2sys", SubState.RUNNING, UnitFileState.ENABLED),
    ("nova-nvpps-hw", SubState.DEAD, UnitFileState.ENABLED),
    ("nova-metadata-generator", SubState.DEAD, UnitFileState.ENABLED),
    ("nova-jetson-clocks", SubState.DEAD, UnitFileState.ENABLED),
    ("nova-can-setup", SubState.DEAD, UnitFileState.ENABLED),
    ("logrotate", SubState.DEAD, UnitFileState.STATIC),
    ("nova-gpio-fix", SubState.DEAD, UnitFileState.ENABLED),
    ("nova-sync-time", SubState.DEAD, UnitFileState.ENABLED),
    ("nova-carter-led", (SubState.EXITED, SubState.DEAD), UnitFileState.ENABLED),
]


@pytest.mark.parametrize("service,exp_state,exp_file_state", SRV_SERVICE_PARAMS, ids=reduceidfn)
def test_service(service, exp_state, exp_file_state):
    if not isinstance(exp_state, (list, tuple)):
        exp_state = (exp_state, )
    if not isinstance(exp_file_state, (list, tuple)):
        exp_file_state = (exp_file_state, )
    unit = Unit(f"{service}.service".encode())
    unit.load()
    unit_file_state_name = unit.Unit.UnitFileState.decode().upper()
    assert unit_file_state_name in UnitFileState.__members__
    unit_file_state = UnitFileState[unit_file_state_name]
    assert unit_file_state in exp_file_state, \
        f"Service not in expected file state ({','.join([s.name for s in exp_file_state])}). Found {unit_file_state.name}."
    sub_state_name = unit.Unit.SubState.decode().upper()
    assert sub_state_name in SubState.__members__, \
        f"Unknown sub state {sub_state_name}"
    sub_state = SubState[sub_state_name]
    if unit_file_state == UnitFileState.STATIC:
        exp_state = exp_state + (SubState.RUNNING, )
        assert sub_state in exp_state, \
            f"Service not in expected state ({','.join([s.name for s in exp_state])}). Found {sub_state.name}."
    else:
        assert sub_state in exp_state, \
            f"Service not in expected state ({','.join([s.name for s in exp_state])}). Found {sub_state.name}."
