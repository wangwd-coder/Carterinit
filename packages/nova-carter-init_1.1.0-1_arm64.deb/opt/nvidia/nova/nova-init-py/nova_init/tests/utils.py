##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
from enum import Enum, auto
from nova_init.utils import (NovaChannels)


class CameraType(Enum):
    HAWK = 0
    REALSENSE = auto()
    OWL = auto()


def condition_float(v, condition, default=False):
    """Returns if float satisfies condition. Handles strings representing nan or inf.

    Args:
        v (Union[str,float,int]): Input value.
        condition (function): Condition to check.
        default (bool): Return boolean if value is not a float.

    Returns:
        bool: Flag indicating if condition was satisfied.
    """
    try:
        if isinstance(v, (str, float, int)):
            f = float(v)
            return condition(f)
        return default
    except ValueError:
        return default


def condition_on_dict_vals(d: dict, condition, base_key="", apply_list=True):
    """Recursively explore nested dictionary and find matching key value pairs that satisfy
    condition.

    Args:
        d (dict): Dictionary to search.
        condition (function): Condition to check. Takes input of value c(v).
        base_key (str, optional): Name of the base key. Defaults to "".
        apply_list (bool, optional): Whether to apply condition to elements of list or tuple.
            Defaults to True.

    Returns:
        list(tuple): List of key value pairs that satisfy condition.
    """
    vals = []
    for k, v in d.items():
        k_out = f"{base_key}/{k}" if base_key else k
        if isinstance(v, dict):
            vals += condition_on_dict_vals(v, condition, base_key=k_out)
        elif apply_list and isinstance(v, (list, tuple)):
            for i, l in enumerate(v):
                if condition(l):
                    list_key = f"{k_out}[{i}]"
                    vals.append((list_key, l))
        elif condition(v):
            vals.append((k_out, v))
    return vals


def access_dict_keys_path(d, keys_path):
    """Access nested dictionary with keys path and assert that they exist. Return final value.

    Args:
        d (dict): Dictionary to access.
        keys_path (list | str): List containing key path or string containing key path separated by
            "/".

    Returns:
        dict: Value of final key accessed.
    """
    if isinstance(keys_path, str):
        keys_path = keys_path.split("/")
    assert isinstance(keys_path, (list, tuple)), \
        f"Keys path \"{keys_path}\" is not a list. Type: {type(keys_path)}."
    base_key = f""
    for k in keys_path:
        assert isinstance(d, dict), \
            f"Passed value is not a dictionary. Type: {type(d)}. Key path: \"{base_key}\""
        assert k in d, f"Key not found in dict. Key: {k}. Key path: {base_key}."
        base_key = f"{base_key}/{k}" if base_key else k
        d = d[k]
    return d


def reduceidfn(param):
    """Reduces auto-generated names for id function.
    
    This is meant to be passed to @pytest.mark.parameterization(ids=reduceidfn)
    """
    if issubclass(type(param), NovaChannels):
        return param.snake_name
    elif issubclass(type(param), Enum):
        return param.name.lower()
    elif isinstance(param, (list, tuple, dict)):
        out = "{"
        for p in param:
            if out != "{":
                out += "-"
            out += reduceidfn(p)
        out += "}"
        return out


def switch_operand(operand, left, right):
    """Switches on an operand string and does the relevant operation to the inputs.

    Args:
        operand (str): operation in string form
        left (any): left side of operand
        right (any): right side of operand

    Returns:
        bool: if the operation succeeded
    """
    if operand == ">=":
        return left >= right
    elif operand == ">":
        return left > right
    elif operand == "<":
        return left < right
    elif operand == "<=":
        return left <= right
    elif operand == "!=":
        return left != right
    elif operand in ["==", ""]:
        return left == right
    else:
        return False
