#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Mount SSD and format if not formatted
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

ssd="nvme0n1"
ssd_path="/dev/$ssd"
ssd_part="${ssd_path}p1"
mount_pt="/mnt/nova_ssd"
fstab_path="/etc/fstab"
tmp_fstab="/tmp/fstab"
fstab_insert="$ssd_part $mount_pt ext4 defaults,nofail 0 2"

# Ask to reformat SSD if it hasn't had a part created
if [ ! -n "$(lsblk -o KNAME,TYPE -n | grep "$ssd" | grep "part")" ]; then
  while true; do
    echobold $(echowarn "NOTE: THIS WILL WIPE YOUR SSD, RUN AT YOUR OWN RISK")
    echo -n $(echobold "About to erase and reformat your SSD at $ssd_path, continue? (yes/no): ")
    read response
    case $response in
      [Yy]es)
        echo "Reformatting the SSD on $ssd_path..."
        parted $ssd_path mklabel gpt
        parted -a opt $ssd_path mkpart primary ext4 0% 100%
        mkfs -t ext4 $ssd_part
        break
        ;;
      [Nn]o)
        echowarn "Not reformatting and setting up $ssd_path. Exiting."
        exit 0
        ;;
      *)
        echo "Invalid response. Please enter 'yes' or 'no'."
        ;;
    esac
  done
fi

# Make directory
if [ ! -d $mount_pt ]; then
  mkdir $mount_pt
fi

# Add ssd to fstab
if ! (grep -q "$ssd_part\|UUID=$(blkid -s UUID -o value $ssd_part)" /etc/fstab); then
  cp $fstab_path $tmp_fstab
  echo "$fstab_insert" >>$tmp_fstab
  safe_cp $tmp_fstab $fstab_path
  echoinfo "Updated $fstab_path with $ssd_part"
fi

# Mount
mount -a
chmod 777 $mount_pt

# Check that SSD is mounted
if ! mount | grep -q "$ssd_part on $mount_pt"; then
  restore_backup "$fstab_path$NOVA_DEFAULT_SUFFIX"
  sed -i "\|^$fstab_path$|d" $NOVA_ADD_LIST
  echoerr "ssd $ssd_part is not mounted on $mount_pt"
  exit 1
fi

# Create subfolders for other applications
mkdir -p $mount_pt/recordings
