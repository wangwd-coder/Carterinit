#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Uninstalls the realsense library
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

librealsense_dir_="$SCRIPT_DIR/librealsense-master"
if [ ! -d $librealsense_dir_ ]; then
  echowarn "librealsense was not downloaded to \"$librealsense_dir_\", nothing to undo"
  exit 0
fi
if [ -d "$librealsense_dir_/build" ]; then
  cd $librealsense_dir_/build
  sudo make uninstall
  make clean
  cd ../../
else
  echowarn "librealsense build folder doesn't exist, continuing undo"
fi
sudo rm -rf $librealsense_dir_
