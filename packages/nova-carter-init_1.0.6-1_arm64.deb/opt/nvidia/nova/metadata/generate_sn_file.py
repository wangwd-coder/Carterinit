#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

# NOTE: command to generate serial number without writing
# python generate_sn_file.py -m carter -i 10 -v 2.3.2 -n

# TODO(bmchale): this file needs to be changed once a persistent method for creating a serial number
#  is made

from argparse import ArgumentParser

from constants import ROBOT_NAME_MAP, ROBOT_SN_LENGTHS_MAP


def check_robot_version(version: str):
    """Checks that the robot version has 3 subcomponents, each subcomponent is numeric, and each
    subcomponent is not greater than 2 digits.
    """
    subversions = version.split(".")
    if len(subversions) != 3:
        return False
    for v in subversions:
        if not v.isnumeric() or len(v) > 2 or len(v) < 1:
            return False
    return True


def check_robot_model(model: str):
    """Checks the robot model is supported.
    """
    return model in ROBOT_NAME_MAP.keys()


def check_robot_index(index: str):
    """Checks the robot index.
    """
    return len(index) <= ROBOT_SN_LENGTHS_MAP["index"]


def get_robot_from_user(model, version, index):
    """Gets robot information (model, version, and index) from user input.
    """
    if not model:
        model = input(f"What's the model? ({','.join(ROBOT_NAME_MAP.keys())})\nModel: ")
        while not check_robot_model(model):
            model = input(
                f"Invalid model name. Must be ({','.join(ROBOT_NAME_MAP.keys())})\nModel: ")
    if not version:
        ex_version = "2.4.3"
        version = input(
            f"What's the robot version? Must be formatted like XX.XX.XX (ex. {ex_version})\n" +
            "Version: ")
        while not check_robot_version(version):
            version = input(
                f"Invalid version. Must be formatted like XX.XX.XX (ex. {ex_version})\nVersion: ")
    if not index:
        index = input(
            f"What's the robot index? This will be used to track your robot with a unique ID. Must be {ROBOT_SN_LENGTHS_MAP['index']} or less chars.\nIndex: "
        )
        while not check_robot_index(index):
            index = input(f"Invalid index. Must not be greater than {ROBOT_SN_LENGTHS_MAP['index']}"
                          "chars.\nIndex: ")
    return model, version, index


def get_robot_sn(model: str, version: str, index: str):
    """Creates serial number from model, version, and index. Assumes WMI is 1NV
    """
    subversions = [v.zfill(2) for v in version.split(".")]
    serial_number = "1NV" + "".join(subversions) + ROBOT_NAME_MAP[model] + \
        index.zfill(ROBOT_SN_LENGTHS_MAP['index'])
    return serial_number


def generate_sn_file(model, version, index, dry_run, output):
    """Generates a file with a serial number."""
    model, version, index = get_robot_from_user(model, version, index)
    serial_number = get_robot_sn(model, version, index)
    if dry_run:
        print(serial_number)
    else:
        with open(output, "w") as f:
            f.write(serial_number + "\n")


def arg_eval(f):
    """Argument checker that takes boolean function and checks the argument inside of it.
    """

    def fn(avalue):
        if not f(avalue):
            raise ValueError
        return avalue

    return fn


def main():
    parser = ArgumentParser()
    parser.add_argument("-m",
                        "--model",
                        choices=ROBOT_NAME_MAP.keys(),
                        type=str,
                        help=f"Model type. Must be one of {','.join(ROBOT_NAME_MAP.keys())}")
    parser.add_argument("-v",
                        "--model-version",
                        type=arg_eval(check_robot_version),
                        help="Model version. Must be formatted like XX.XX.XX (ex. 2.3.1)")
    parser.add_argument(
        "-i",
        "--index",
        type=arg_eval(check_robot_index),
        help=f"Model index. Must not be greater than {ROBOT_SN_LENGTHS_MAP['index']} digits.")
    parser.add_argument("-o",
                        "--output",
                        default="/etc/nova/serial_number",
                        type=str,
                        help="Output path for serial number.")
    parser.add_argument("-n",
                        "--dry-run",
                        action="store_true",
                        help="Generates metadata and outputs results without writing.")
    args = parser.parse_args()
    if not args.model and not args.model_version:
        def_model = "carter"
        def_version = "2.4.3"
        yes_fields = ["y", "Y", "yes"]
        no_fields = ["n", "N", "no"]
        ans = input(
            f"Would you like to use defaults for Nova Carter serial number? This is recommended if purchased from Segway Robotics. (y/n)"
        )
        while ans not in yes_fields + no_fields:
            ans = input("Invalid response. Please respond (y/n)")
        if ans in yes_fields:
            generate_sn_file(def_model, def_version, args.index, args.dry_run, args.output)
        elif ans in no_fields:
            generate_sn_file(args.model, args.model_version, args.index, args.dry_run, args.output)


if __name__ == "__main__":
    main()
