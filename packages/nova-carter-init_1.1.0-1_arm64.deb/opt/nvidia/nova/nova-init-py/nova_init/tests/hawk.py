#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
import math
from pathlib import Path
import pytest
import subprocess
import yaml

from nova_init.tests.utils import (reduceidfn, access_dict_keys_path, condition_on_dict_vals,
                                   condition_float)
from nova_init.utils import (HAWK_ID_MAP)

HAWK_EEPROM_INPUTS = []    # list of hawk ids for reading eeprom


# Apply python fixture outside. Necessary to choose custom input params.
# Example: setup_hawk_eeprom = pytest.fixture(setup_hawk_eeprom, scope='class', params=[(NovaChannels.kFrontStereoCamera), (NovaChannels.kRightStereoCamera)])
def setup_hawk_eeprom(request):
    assert request.param in HAWK_ID_MAP, f"{request.param} not mapped to a hawk id"
    id = HAWK_ID_MAP[request.param]
    exe = Path(__file__).joinpath("../../../../tools/hawk/eeprom/build/print_eeprom").resolve()
    yaml_file = f"/tmp/liee-{int(id)}.yaml"
    cmd = f"{exe} -f {yaml_file} {id}"
    out = subprocess.check_output(cmd.split())
    with open(yaml_file, 'r', errors='replace') as f:
        data = f.read()
    eeprom = yaml.safe_load(data)
    yield eeprom


@pytest.mark.hawk
@pytest.mark.eeprom
class TestHawkEeprom:

    def test_serial_number(self, setup_hawk_eeprom):
        eeprom = setup_hawk_eeprom
        sn = eeprom["serial_number"]
        assert sn.isalnum(), f"Serial number should be alphanumeric. Got {sn}"
        assert sn.isupper(), f"Serial number should be upper case. Got {sn}"

    @pytest.mark.parametrize("keys", [
        ("left_cam_intr"),
        ("right_cam_intr"),
    ], ids=reduceidfn)
    def test_img_size(self, setup_hawk_eeprom, keys):
        eeprom = setup_hawk_eeprom
        cam_intr = access_dict_keys_path(eeprom, keys)
        height, width = cam_intr["height"], cam_intr["width"]
        h_ratio = 10
        w_ratio = 16
        assert (
            float(w_ratio) / float(h_ratio)
        ) * height == width, f"Height and width are not a {w_ratio}:{h_ratio} ratio. width: {width} height: {height}"

    def test_gravity_acceleration(self, setup_hawk_eeprom):
        eeprom = setup_hawk_eeprom
        grav_acc = eeprom["imu"]["gravity_acceleration"]
        assert (abs(grav_acc[0]) == 9.8 or grav_acc[1] == 9.8
                or grav_acc[2] == 9.8), f"Gravity acceleration incorrect, got {grav_acc}"
        # sgillen: can add these back once all hawks are flashed with updated data,
        # Not to mention once someone actually uses this for anything
        # assert not (grav_acc[0] == grav_acc[1] and grav_acc[0] == grav_acc[2] and \
        #     grav_acc[1] == grav_acc[2]), f"Gravity vector can't have all the same components. Got " \
        #         f"{grav_acc}"

    def test_finite(self, setup_hawk_eeprom):
        eeprom = setup_hawk_eeprom

        def is_not_finite(v):
            return not condition_float(v, math.isfinite, default=True)

        vals = condition_on_dict_vals(eeprom, is_not_finite)
        assert not vals, f"Not all keys are finite in HAWK eeprom. Keys that aren't finite {vals}."

    @pytest.mark.parametrize("keys", [
        ("nm/update_rate"),
        ("nm/linear_acceleration_noise_density"),
        ("nm/linear_acceleration_random_walk"),
        ("nm/angular_velocity_noise_density"),
        ("nm/angular_velocity_random_walk"),
    ],
                             ids=reduceidfn)
    def test_non_zero(self, setup_hawk_eeprom, keys):
        tmp = setup_hawk_eeprom
        tmp = access_dict_keys_path(tmp, keys)

        def is_non_zero(v):
            return condition_float(v, lambda x: x != 0.0)

        assert is_non_zero(tmp), f"Float is zero or not a number. Got {tmp}."
