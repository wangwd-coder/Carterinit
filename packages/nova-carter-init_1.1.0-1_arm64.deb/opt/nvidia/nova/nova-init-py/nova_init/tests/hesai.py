#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

import time
import os
import pytest
import logging

from nova_init.hesai import HesaiLidar, HesaiPtpStatusType

N_LOCK_SAMPLES = 5
N_FREQ_SAMPLES = 10
MAX_DRIFT_NS = 10000    # 10us
ALLOW_ATTEMPTS = 1


@pytest.mark.hesai
def test_hesai_ping(hesai_ip):
    assert os.system(f"ping -c 1 {hesai_ip} >/dev/null") == 0, f"Can't ping hesai at {hesai_ip}"


@pytest.mark.hesai
def test_ptp_lock(hesai_ip):
    test_hesai_ping(hesai_ip)
    lidar = HesaiLidar(hesai_ip)
    prev_status = HesaiPtpStatusType.TRACKING
    attempts = 0
    sequential_locks = 0
    track_timeout = 10
    start_time = time.perf_counter()
    while True:
        ptp_status = lidar.get_ptp_status()
        status = ptp_status.status
        offset = ptp_status.offset
        assert offset < MAX_DRIFT_NS, f"Offset {offset}ns exceeds tolerance of {MAX_DRIFT_NS}ns while in state {status.name}."
        dt = time.perf_counter() - start_time
        if status in [HesaiPtpStatusType.TRACKING, HesaiPtpStatusType.FROZEN]:
            # Attempt to recover tracking state and timeout after a period, if the attempts exceeds the amount allowed also error
            if prev_status == HesaiPtpStatusType.LOCKED:
                sequential_locks = 0
                attempts += 1
                assert attempts <= ALLOW_ATTEMPTS, f"Attempt {attempts} exceeds max number of allowed attempts {ALLOW_ATTEMPTS} to recover locked state. Current state {status.name}."
            logging.debug(f"Attempt {attempts} to enter locked state while in {status.name}")
            assert dt < track_timeout, f"In state {status.name} for more than {track_timeout} seconds"
        elif status == HesaiPtpStatusType.LOCKED:
            # Exit successfully once N locks are achieved in a row
            start_time = time.perf_counter()
            sequential_locks += 1
            logging.debug(f"In lock state {sequential_locks} times in a row")
            if sequential_locks > N_LOCK_SAMPLES:
                break
        else:
            assert False, f"Invalid PTP status {status.name}"
        time.sleep(0.5)
        prev_status = status
