/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#define u8 uint8_t
#define u16 uint16_t
#define u32 uint32_t

#define MAX_RADIAL_COEFFICIENTS 6
#define MAX_TANGENTIAL_COEFFICIENTS 2
#define MAX_FISHEYE_COEFFICIENTS 6
#define LEOP_CAMERA_MAX_SN_LENGTH 10
#define MAX_RLS_COLOR_CHANNELS 4
#define MAX_RLS_BREAKPOINTS 6

// Coefficients as per distortion model (wide FOV) being used
typedef struct {
  // Radial coefficients count
  u32 coeff_count;
  // Radial coefficients
  float k[MAX_FISHEYE_COEFFICIENTS];
  // 0 -> equidistant, 1 -> equisolid, 2 -> orthographic, 3 -> stereographic
  u32 mapping_type;
} fisheye_lens_distortion_coeff;

// Coefficients as per distortion model being used
typedef struct {
  // Radial coefficients count
  u32 radial_coeff_count;
  // Radial coefficients
  float k[MAX_RADIAL_COEFFICIENTS];
  // Tangential coefficients count
  u32 tangential_coeff_count;
  // Tangential coefficients
  float p[MAX_TANGENTIAL_COEFFICIENTS];
} polynomial_lens_distortion_coeff;

/*
 * Stereo Eeprom Data
 */
typedef struct {
  // Width and height of image in pixels
  u32 width, height;
  // Focal length in pixels
  float fx, fy;
  float skew;
  // Principal point (optical center) in pixels
  float cx, cy;
  /*
   * Structure for distortion coefficients as per the model being used
   * 0: pinhole, assuming polynomial distortion
   * 1: fisheye, assuming fisheye distortion)
   * 2: ocam (omini-directional)
   */
  u32 distortion_type;
  union distortion_coefficients {
    polynomial_lens_distortion_coeff poly;
    fisheye_lens_distortion_coeff fisheye;
  } dist_coeff;
} camera_intrinsics;

/*
 * Extrinsic parameters shared by camera and IMU.
 * All rotation + translation with respect to the same reference point
 */
typedef struct {
  /*
   * Rotation parameter expressed in Rodrigues notation
   * angle = sqrt(rx^2+ry^2+rz^2)
   * unit axis = [rx,ry,rz]/angle
   */
  float rx, ry, rz;
  // Translation parameter from one camera to another parameter
  float tx, ty, tz;
} camera_extrinsics;

/*
 * IMU parameters used by HAWK 1.0. HAWK 1.0 did not have IMU noise model parameters
 * in EEPROM. To preserve backward compatibility with HAWK 1.0, the EEPROM data is arranged
 * in a certain way which requires tracking the imu noise model parameters in a
 * separate structure.
 */
typedef struct {
  // 3D vector to add to accelerometer readings
  float linear_acceleration_bias[3];
  // 3D vector to add to gyroscope readings
  float angular_velocity_bias[3];
  // gravity acceleration
  float gravity_acceleration[3];
  // Extrinsic structure for IMU device
  camera_extrinsics extr;

} imu_params_v1;

typedef struct {
  /*
   *Noise model parameters
   */

  float update_rate;
  float linear_acceleration_noise_density;
  float linear_acceleration_random_walk;
  float angular_velocity_noise_density;
  float angular_velocity_random_walk;

} imu_params_noise_m;

typedef struct {
  // Image height
  u16 image_height;
  // Image width
  u16 image_width;
  // Number of color channels
  u8 n_channels;
  // Coordinate x of center point
  float rls_x0[MAX_RLS_COLOR_CHANNELS];
  // Coordinate y of center point
  float rls_y0[MAX_RLS_COLOR_CHANNELS];
  // Ellipse xx parameter
  double ekxx[MAX_RLS_COLOR_CHANNELS];
  // Ellipse xy parameter
  double ekxy[MAX_RLS_COLOR_CHANNELS];
  // Ellipse yx parameter
  double ekyx[MAX_RLS_COLOR_CHANNELS];
  // Ellipse yy parameter
  double ekyy[MAX_RLS_COLOR_CHANNELS];
  // Number of breakpoints in LSC radial transfer function
  u8 rls_n_points;
  // LSC radial transfer function X
  float rls_rad_tf_x[MAX_RLS_COLOR_CHANNELS][MAX_RLS_BREAKPOINTS];
  // LSC radial transfer function Y
  float rls_rad_tf_y[MAX_RLS_COLOR_CHANNELS][MAX_RLS_BREAKPOINTS];
  // LSC radial transfer function slope
  float rls_rad_tf_slope[MAX_RLS_COLOR_CHANNELS][MAX_RLS_BREAKPOINTS];
  // rScale parameter
  u8 r_scale;
} radial_lsc_params;

typedef struct {
  /**
   * EEPROM layout version
   */
  u32 version;
  /**
   * Factory Blob Flag, to set when factory flashed and reset to 0
   * when user modified
   */
  u32 factory_data;
  /**
   * Intrinsic structure for camera device
   */
  camera_intrinsics left_cam_intr;
  camera_intrinsics right_cam_intr;
  /**
   * Extrinsic structure for camera device
   */
  camera_extrinsics cam_extr;
  /**
   * Flag for IMU 0-absent, 1-present
   */
  u8 imu_present;
  /**
   * Intrinsic structure for IMU
   */
  imu_params_v1 imu;

  u8 tmp[16];

  // HAWK module serial number
  u8 serial_number[LEOP_CAMERA_MAX_SN_LENGTH];

  imu_params_noise_m nm;

  // Radial Lens Shading Correction parameters
} hawk_eeprom_struct;
