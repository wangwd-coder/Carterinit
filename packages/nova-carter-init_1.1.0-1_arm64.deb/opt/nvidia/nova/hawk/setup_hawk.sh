#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Sets up HAWK drivers
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../utils.sh
source $SCRIPT_DIR/../exit.sh

modprobe_conf="nova-hawk.conf"
modprobe_dst="/etc/modprobe.d/$modprobe_conf"

# Add mod files
for file in "$SCRIPT_DIR"/*.ko; do
  if [ -f "$file" ]; then
    safe_cp_mod "$file"
  fi
done

# Update owner of ISP file
chown root:root /var/nvidia/nvcam/settings/camera_overrides.isp

# Add modprobe file
safe_cp $SCRIPT_DIR/$NOVA_ROBOT_PRE.$modprobe_conf $modprobe_dst
