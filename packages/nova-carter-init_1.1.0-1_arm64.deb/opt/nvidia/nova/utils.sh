#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Utilities for managing debian package
NOVA_BASE_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $NOVA_BASE_DIR/log_utils.sh
NOVA_DEFAULT_SUFFIX=".nova.disabled"
NOVA_DEFAULT_GROUP="nova"
NOVA_ID_ATTR="group"
LINUX_MOD_DIR="/lib/modules/$(uname -r)/"
NOVA_ADD_LIST="$NOVA_BASE_DIR/added_files.txt"  # list of files that were added by NOVA
NOVA_RM_LIST="$NOVA_BASE_DIR/removed_files.txt" # list of files that were removed by NOVA

# Store robot info in variables for other scripts
robot_sn_file_="/etc/nova/serial_number"
if [ ! -f $robot_sn_file_ ]; then
  echoerr "$robot_sn_file_ doesn't exist"
  return 1
fi
NOVA_ROBOT_SN="$(cat /etc/nova/serial_number)"
NOVA_ROBOT_ID="${NOVA_ROBOT_SN:9:2}"
NOVA_ROBOT_MAJORV="${NOVA_ROBOT_SN:3:2}"                               # only major and minor version
NOVA_ROBOT_MAJORV="${NOVA_ROBOT_MAJORV#"${NOVA_ROBOT_MAJORV%%[!0]*}"}" # strip leading 0
NOVA_ROBOT_MINORV="${NOVA_ROBOT_SN:5:2}"
NOVA_ROBOT_MINORV="${NOVA_ROBOT_MINORV#"${NOVA_ROBOT_MINORV%%[!0]*}"}"
if [ "$NOVA_ROBOT_ID" = "NI" ]; then
  NOVA_ROBOT_ID="${NOVA_ROBOT_SN:11:2}"
fi
NOVA_ROBOT_PRE=""
case "$NOVA_ROBOT_ID" in
  "CR")
    NOVA_ROBOT_PRE="carter-$NOVA_ROBOT_MAJORV-$NOVA_ROBOT_MINORV"
    ;;
  "RR")
    NOVA_ROBOT_PRE="carter-2-3"
    ;;
  *)
    echowarn "$NOVA_ROBOT_ID is not a valid identifier"
    ;;
esac

# Keeps a history of a specified value, used for maintenance/recovery
store_history() {
  if [ -z $1 ]; then
    echoerr "pass HISTORY FILE"
    return 1
  fi
  if [ -z $2 ]; then
    echoerr "pass VALUE"
    return 1
  fi
  local history_file="$1"
  local val="$2"
  if [[ ! -f "$history_file" ]]; then # empty file
    touch "$history_file"
    mark_file "$history_file"
  fi
  s="$val"
  f="$history_file"
  grep -qxF "$s" $f || echo "$s" >>$f
}

# Marks a file with an attribute that identifies it was created by this package
mark_file() {
  if [ -z $1 ]; then
    echoerr "pass FILE"
    return 1
  fi
  local file="$1"
  attr -q -s $NOVA_ID_ATTR -V $NOVA_DEFAULT_GROUP $file
  store_history "$NOVA_ADD_LIST" "$file"
}

# Not meant for use directly
_safe_cmd() {
  if [ -z "$1" ]; then
    echoerr "$($FUNCNAME $@) failed, pass CMD"
    return 1
  fi
  local cmd=$1
  local source=""
  local dest=""
  case $cmd in
    cp | mv)
      source=$2
      dest=$3
      ;;
    rm)
      dest=$2
      ;;
    \?)
      echoerr "Command isn't supported: $OPTARG"
      return 1
      ;;
  esac
  local suffix="$NOVA_DEFAULT_SUFFIX"
  local bak_dest="$dest$suffix"
  if [ -f $bak_dest ]; then
    echoerr "backup $bak_dest already exist"
    return 2
  fi
  if [ -n "$source" ] && [ -n "$dest" ]; then # take a source, copy or move, and backup
    #TODO(bmchale): look into using dpkg-divert for file management
    $cmd -b -S $suffix $source $dest
    mark_file $dest
  elif [ -n "$dest" ]; then # remove and backup a single file
    mv $dest $bak_dest
    store_history "$NOVA_RM_LIST" "$dest"
  else
    echoerr "$FUNCNAME function is not setup correctly"
    return 2
  fi
}

safe_rm() {
  local usage="
Usage: $FUNCNAME [-h] FILE

Safe removes a file. Backs up file if backup doesn't exist and errors otherwise.

where:
    -h  show this help text
"
  # Parse command-line options
  while getopts ":h" opt; do
    case $opt in
      h)
        echo "$usage"
        return 0
        ;;
      \?)
        echoerr "Invalid option: -$OPTARG"
        echo "$usage" 1>&2
        return 1
        ;;
    esac
  done
  # Shift the parsed options
  shift $((OPTIND - 1))
  if [ -z "$1" ]; then
    echoerr "$($(basename $0) $@) failed, pass FILE"
    return 1
  fi
  _safe_cmd "rm" $1
}

safe_mv() {
  local usage="
Usage: $FUNCNAME [-h] SOURCE DEST

Safe moves a file. Backs up file if backup doesn't exist and errors otherwise.

where:
    -h  show this help text
"
  # Parse command-line options
  while getopts ":h" opt; do
    case $opt in
      h)
        echo "$usage"
        return 0
        ;;
      \?)
        echoerr "Invalid option: -$OPTARG"
        echo "$usage" 1>&2
        return 1
        ;;
    esac
  done
  # Shift the parsed options
  shift $((OPTIND - 1))
  if [ -z "$1" ]; then
    echoerr "$($(basename $0) $@) failed, pass SOURCE"
    return 1
  fi
  if [ -z "$2" ]; then
    echoerr "$($(basename $0) $@) failed, pass DEST"
    return 1
  fi
  _safe_cmd "mv" $1 $2
}

# Safe copies a file. Backs up file if backup doesn't exist and errors otherwise.
safe_cp() {
  local usage="
Usage: $FUNCNAME [-h] SOURCE DEST

Safe copies a file. Backs up file if backup doesn't exist and errors otherwise.

where:
    -h  show this help text
"
  # Parse command-line options
  while getopts ":h" opt; do
    case $opt in
      h)
        echo "$usage"
        return 0
        ;;
      \?)
        echoerr "Invalid option: -$OPTARG"
        echo "$usage" 1>&2
        return 1
        ;;
    esac
  done
  # Shift the parsed options
  shift $((OPTIND - 1))
  if [ -z "$1" ]; then
    echoerr "\`$FUNCNAME $@\` failed, pass SOURCE"
    return 1
  fi
  if [ -z "$2" ]; then
    echoerr "\`$FUNCNAME $@\` failed, pass DEST"
    return 1
  fi
  _safe_cmd "cp" $1 $2
}

# Finds a single file within the given path and errors if more than one are found
find_one() {
  if [ -z $1 ]; then
    echoerr "pass path to $0"
    return 1
  fi
  if [ -z $2 ]; then
    echoerr "pass file to $0"
    return 1
  fi
  local path=$1
  local file=$2
  local find_res=$(find $path -path $NOVA_BASE_DIR -prune -false -o -type f -name $file)
  local line_count=$(echo "$find_res" | wc -l)
  if [ "$line_count" -gt 1 ]; then
    echoerr "found more than one file \"$file\". Files: \"$find_res\""
    return 1
  fi
  echo "$find_res"
}

# Finds mod file path
find_mod() {
  if [ -z $1 ]; then
    echoerr "pass file to $0"
    return 1
  fi
  echo "$(find_one $LINUX_MOD_DIR $1)"
}

# Restore backup files
restore_backup() {
  if [ -z $1 ]; then
    echoerr "pass BACKUP"
    return 1
  fi
  local backup="$1"
  local orig_file="${backup%$NOVA_DEFAULT_SUFFIX}"
  if [ ! -f $orig_file ]; then
    mv $backup $orig_file
    return 0
  fi
  # Restore backup if attr is part of group
  if [ "$(attr -q -g $NOVA_ID_ATTR $orig_file)" = "$NOVA_DEFAULT_GROUP" ]; then
    mv $backup $orig_file
  else # keep current if attr is missing (assumes L4T or other pkg placed it there)
    local old_file="$backup.old"
    echowarn "$orig_file does not have $NOVA_ID_ATTR attr \"$NOVA_DEFAULT_GROUP\". Moving backup " \
      "to \"$old_file\"."
    mv $backup $old_file
  fi
}

# Safe copy a mod file
safe_cp_mod() {
  if [ -z $1 ]; then
    echoerr "pass MOD FILE to $FUNCNAME"
    return 1
  fi
  file="$1"
  dest="$(find_mod $(basename $file))"
  if [[ ! -f $dest ]]; then
    echoerr "\`$FUNCNAME $file\` could not find mod in $LINUX_MOD_DIR"
    return 1
  fi
  safe_cp $file $dest
}

# Get subdomain from IP address
get_subdomain() {
  if [ -z $1 ]; then
    echo "pass IP"
    return 1
  fi
  echo "$(echo "$1" | cut -d '.' -f 1-3)"
}

# Re-configure IP and reload routing table
reconfigure_ip() {
  if [ -z $1 ]; then
    echo "pass ETH"
    return 1
  fi
  if [ -z $2 ]; then
    echo "pass IP"
    return 1
  fi
  eth="$1"
  ip="$2"
  sudo ifconfig $eth "$ip"
  sudo ip route replace "$(get_subdomain $ip).0/24" dev $eth
}
