#!/usr/bin/python3
##############################################################################
# Copyright (c) 2022-2023, NVIDIA CORPORATION. All rights reserved.          #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

import io
import logging
import pandas as pd
import pathlib
import re
import subprocess
import time

import nova_init.hesai.hesai_utils as hesai
from nova_init.metadata.constants import (ROBOT_NAME_MAP, ROBOT_SN_LENGTHS_MAP, ROBOT_SN_MAX_LENGTH)
from nova_init.utils import (NovaChannels, HAWK_ID_MAP)

NOT_APPLICABLE = "n/a"


def get_key_from_value(d, value):
    """Gets key from dictionary given a value.
    """
    return list(d.keys())[list(d.values()).index(value)]


def get_model_from_map(abbr):
    """Gets model using abbreviation.
    """
    return get_key_from_value(ROBOT_NAME_MAP, abbr)


def clean_string(data: str):
    """Removes extra parts of string read from file.
    """
    return data.replace("\u0000", "")


def get_serial_number():
    """Gets serial number from persistent file."""
    path = pathlib.Path("/etc/nova/serial_number")
    if not path.is_file():
        raise ValueError(f"{path.resolve()} is not a file. Can't create metadata. Run "
                         "usr/bin/NOVA/generate_sn_file.py to generate a serial number.")
    with open(path.resolve(), 'r') as f:
        sn = f.readline().rstrip('\n')
        return sn


def get_sn_parts(sn: str):
    """Gets parts of a serial number. Returns model, model version, and index."""
    if len(sn) != ROBOT_SN_MAX_LENGTH:
        raise ValueError(f"Robot serial number must be {ROBOT_SN_MAX_LENGTH} digits, not {len(sn)}")
    model_version = model = index = None
    start = 0
    i = 0
    while start < ROBOT_SN_MAX_LENGTH:
        step = list(ROBOT_SN_LENGTHS_MAP.values())[i]
        end = start + step
        part = sn[start:end]
        key = list(ROBOT_SN_LENGTHS_MAP.keys())[i]
        if key == "wmi":
            pass
        elif key == "version":
            model_version = ".".join([str(int(part[x:x + 2])) for x in range(0, len(part), 2)])
        elif key == "model":
            model = get_model_from_map(part)
        elif key == "index":
            index = part
        else:
            raise ValueError(f"Invalid key {key} in ROBOT_SN_LENGTHS_MAP")
        start = end
        i += 1
    if model_version is None or model is None or index is None:
        raise ValueError(f"Failed at reading sn parts.")
    return model, model_version, index


def get_tegra_sn():
    """Gets the tegra serial number.
    """
    tegra_sn_file = "/sys/firmware/devicetree/base/serial-number"
    with open(tegra_sn_file, "r") as file:
        return clean_string(file.read())


def get_tegra_type():
    """Gets the tegra type.
    """
    model_file = "/sys/firmware/devicetree/base/model"
    with open(model_file, "r") as file:
        return clean_string(file.read())


def get_jetpack_version():
    """Gets the jetpack version using system file.
    """
    cmd = "apt policy nvidia-jetpack"
    out = subprocess.check_output(cmd.split())
    out_data = out.decode('utf-8')
    match = re.search(r"Installed:\s+(.*)", out_data)
    if match is None:
        raise ValueError(f"Field \"Installed: \" does not exist in output of command `{cmd}`")
    return match.group(1)


def get_hesai_sn(ipv4="192.168.1.201"):
    """Gets hesai lidar serial number.
    """
    lidar = hesai.HesaiLidar(ipv4)
    try:
        sn = lidar.get_serial_number()
    except (subprocess.CalledProcessError) as e:
        return NOT_APPLICABLE
    return sn


def get_hawk_sn(sensor: NovaChannels, timeout=60):
    """Gets hawk serial number using ID.
    """
    if sensor not in HAWK_ID_MAP:
        raise ValueError(f"{sensor} is not part of of HAWK id map")
    id = HAWK_ID_MAP[sensor]

    cmd = f"/opt/nvidia/nova/tools/hawk/eeprom/build/print_eeprom -n -v {id}"

    out = None
    start_time = time.perf_counter()
    while True:
        try:
            out = subprocess.check_output(cmd.split())
            break
        except (subprocess.CalledProcessError) as e:
            dt = time.perf_counter() - start_time
            if dt >= timeout:
                logging.warn(
                    f"Timed out waiting for `{cmd}` to run without error. Waited {dt}s. Timeout was {timeout}s"
                )
                return NOT_APPLICABLE
            time.sleep(1)
    try:
        out_data = out.decode('utf-8')
    except Exception as e:
        return NOT_APPLICABLE
    match = re.search(r"serial_number:\s+(.*)", out_data)
    if match is None:
        raise ValueError(f"Field \"serial_number: \" does not exist in output of command `{cmd}`")
    return match.group(1)


def get_owl_sn(sensor: NovaChannels):
    """Gets OWL serial number using ID."""
    # TODO(bmchale): fill in similar to hawk once serial number can be captured through argus
    return NOT_APPLICABLE


def get_realsense_sn(id: int):
    """Gets realsense serial number using ID.
    """
    out = subprocess.check_output(["rs-enumerate-devices", "-s"])
    out_data = out.decode('utf-8')
    df = pd.read_csv(io.StringIO(out_data), sep='\s{2,}', engine='python', thousands=',')
    if "Serial Number" not in df.columns:
        raise ValueError(
            f"'Serial Number' column does not exist in rs-enumerate-devices output. Output:\n{df}")
    if id >= df.shape[0]:
        raise ValueError(f"Realsense ID {id} out of range. Found {df.shape[0]} devices.")
    return str(df.loc[id, "Serial Number"])


def get_segway_drivetrain_sn():
    """Gets segway drivetrain serial number.
    """
    logging.warning("Using robot serial number for drivetrain")
    return get_serial_number()


def get_rplidar_sn(ip):
    """Gets rplidar serial number using ip."""
    cmd = f"/opt/nvidia/nova/rplidar/build/get_rplidar_sn {ip}"
    try:
        out = subprocess.check_output(cmd.split())
    except (subprocess.CalledProcessError) as e:
        return NOT_APPLICABLE
    out_data = out.decode('utf-8')
    match = re.search(r"serial_num:\s+(.*)", out_data)
    if match is None:
        raise ValueError(f"Field \"serial_num: \" does not exist in output of command `{cmd}`")
    return match.group(1)
