/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <spdlog/spdlog.h>
#include <iostream>
#include "cxxopts.hpp"
#include "sl_lidar.h"
#include "sl_lidar_driver.h"

using namespace sl;
int main(int argc, char** argv) {
  cxxopts::Options options("get_rplidar_sn", "Gets an RPLIDARs SN and prints it to screen.");
  options.positional_help("<ip>");
  options.add_options()("ip", "Current IP of RPLIDAR", cxxopts::value<std::string>())(
      "h,help", "Print usage");
  options.parse_positional({"ip"});
  auto result = options.parse(argc, argv);
  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    exit(0);
  }
  auto ip = result["ip"].as<std::string>();
  std::unique_ptr<IChannel> channel(*createUdpChannel(ip, 8089));
  std::unique_ptr<ILidarDriver> lidar(*createLidarDriver());
  auto res = lidar->connect(channel.get());
  if (SL_IS_OK(res)) {
    sl_lidar_response_device_info_t device_info;
    res = lidar->getDeviceInfo(device_info);
    if (!SL_IS_OK(res)) {
      spdlog::error("Current lidar IP address {} won't communicate, exiting...", ip);
      exit(1);
    }
    size_t sz = sizeof(device_info.serialnum) / sizeof(device_info.serialnum[0]);
    printf("serial_num: ");
    for (uint i = 0; i < sz; i++) {
      printf("%02X", device_info.serialnum[i]);
    }
    printf("\n");
  } else {
    spdlog::error("Failed to connect to lidar {}...", ip);
    exit(1);
  }
}
