#!/usr/bin/env python
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
# Dummy setup file to install in editable mode
# https://stackoverflow.com/a/68939858
# NOTE: removable after pip 21.1 becomes default
import setuptools

if __name__ == "__main__":
    setuptools.setup()
