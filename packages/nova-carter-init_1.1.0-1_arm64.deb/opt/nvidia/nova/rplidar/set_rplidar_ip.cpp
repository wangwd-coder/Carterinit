/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <spdlog/spdlog.h>
#include <iostream>
#include "cxxopts.hpp"
#include "sl_lidar.h"
#include "sl_lidar_driver.h"

using namespace sl;
int main(int argc, char** argv) {
  cxxopts::Options options("set_rplidar_ip", "Sets an RPLIDAR's IP address to a given value.");
  options.positional_help("<ip> <new_ip>");
  options.add_options()("ip", "Current IP of RPLIDAR", cxxopts::value<std::string>())(
      "new_ip", "New IP for RPLIDAR", cxxopts::value<std::string>())("h,help", "Print usage");
  options.parse_positional({"ip", "new_ip"});
  auto result = options.parse(argc, argv);
  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    exit(0);
  }
  auto ip = result["ip"].as<std::string>();
  auto new_ip = result["new_ip"].as<std::string>();
  // Check if new lidar exists and exit if so
  std::unique_ptr<IChannel> new_channel(*createUdpChannel(new_ip, 8089));
  std::unique_ptr<ILidarDriver> new_lidar(*createLidarDriver());
  auto new_res = new_lidar->connect(new_channel.get());
  if (SL_IS_OK(new_res)) {
    sl_lidar_response_device_info_t device_info;
    new_res = new_lidar->getDeviceInfo(device_info);
    if (SL_IS_OK(new_res)) {
      spdlog::error("New IP address {} is already used, exiting...", new_ip);
      exit(1);
    }
  }
  // Change lidar IP by connecting and sending command
  std::unique_ptr<IChannel> channel(*createUdpChannel(ip, 8089));
  std::unique_ptr<ILidarDriver> lidar(*createLidarDriver());
  auto res = lidar->connect(channel.get());
  if (SL_IS_OK(res)) {
    // Check if communication is possible before setting
    sl_lidar_response_device_info_t device_info;
    res = lidar->getDeviceInfo(device_info);
    if (!SL_IS_OK(res)) {
      spdlog::error("Current lidar IP address {} won't communicate, exiting...", ip);
      exit(1);
    }
    // Set IP
    std::stringstream ss(new_ip);
    std::string token;
    sl_lidar_ip_conf_t conf = {{192, 168, 11, 2}, {255, 255, 255, 0}, {192, 168, 11, 2}};
    uint index = 0;
    while (getline(ss, token, '.')) {
      if (index >= 4) {
        break;
      } else if (index == 3) {
        conf.ip_addr[index] = std::stoi(token);
        conf.gw[index] = 1;
      } else {
        conf.ip_addr[index] = std::stoi(token);
        conf.gw[index] = std::stoi(token);
      }
      index++;
    }
    if (index != 4) {
      spdlog::error("Found {} subnets. Expected 4 from IP {}.", index, new_ip);
      exit(1);
    }
    res = lidar->setLidarIpConf(conf);
    if (SL_IS_OK(res)) {
      spdlog::info("Set lidar IP address to {}! Resetting the lidar...", new_ip);
      lidar->reset();
    } else {
      spdlog::error("Failed to set lidar IP {}...", new_ip);
      exit(1);
    }
  } else {
    spdlog::error("Failed to connect to lidar {}...", ip);
    exit(1);
  }
}
