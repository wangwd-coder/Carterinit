#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Setup script for exiting with meaning
NOVA_BASE_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $NOVA_BASE_DIR/log_utils.sh
set -eE -o functrace

traceback() {
  local errcode="$?"
  local cmd=${BASH_COMMAND}
  set +o xtrace
  echoerr "${BASH_SOURCE[1]}:${BASH_LINENO[0]} ('$cmd' exited with code $errcode)"
}
trap 'traceback' ERR
