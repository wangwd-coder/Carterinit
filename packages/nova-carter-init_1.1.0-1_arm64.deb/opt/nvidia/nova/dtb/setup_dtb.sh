#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# This script configures the device tree
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../utils.sh
source $SCRIPT_DIR/../exit.sh

extlinux_file=/boot/extlinux/extlinux.conf
base_file_="tegra234-p3701-0000-p3737-0000"
bootdir_file_="kernel_${base_file_}"
overlay_name_="$NOVA_ROBOT_PRE"
overlay_file_="$SCRIPT_DIR/$overlay_name_.dtsi"
args_=(-n)

case "$NOVA_ROBOT_ID" in
  "CR")
    case "$NOVA_ROBOT_MAJORV-$NOVA_ROBOT_MINORV" in
      "2-4")
        args_+=(2="Jetson Camera Hawk-Owl p3762 module")
        ;;
      "2-3")
        args_+=(2="Jetson Camera e3653-dual-Hawk module")
        ;;
      *)
        echoerr "$NOVA_ROBOT_PRE invalid"
        exit 1
        ;;
    esac
    ;;
  "RR")
    args_+=(2="Jetson Camera e3653-dual-Hawk module")
    ;;
  *)
    echoerr "$NOVA_ROBOT_ID is not a valid identifier"
    ;;
esac
# Add dtb/dtbo files
for file in "$SCRIPT_DIR"/*.dtb "$SCRIPT_DIR"/*.dtbo; do
  if [ -f "$file" ]; then
    base=$(basename "$file")
    safe_cp $file $(find_one /boot/ $base)
    jio_file="/boot/dtb/kernel_$base"
    if [ -f $jio_file ]; then # Copy to /boot/dtb/ for jetson-io if the file exists there
      safe_cp $file $jio_file
    fi
  fi
done
# Place L4T base dtb file if it was accidentally deleted
if [ ! -f /boot/dtb/${bootdir_file_}.dtb ]; then
  echowarn "/boot/dtb/${bootdir_file_}.dtb is missing, adding it back using /boot/${base_file_}.dtb"
  safe_cp /boot/${base_file_}.dtb /boot/dtb/${bootdir_file_}.dtb
fi
# Replace dtbs in /boot/dtb with /boot/ equivalent if they are older than jetpack version
nv_tegra_date=$(cat /etc/nv_tegra_release | grep -o "DATE:.*" | sed 's/DATE: //')
nv_tegra_secs=$(date -d "$nv_tegra_date" "+%s")
for file in "/boot/dtb"/*; do
  if [ -f "$file" ]; then
    file_secs="$(stat -c %Y $file)"
    if [ "$file_secs" -lt "$nv_tegra_secs" ]; then
      target_file="/boot/$(basename "$file" | sed 's/kernel_//')"
      echowarn "$file is older than last jetson build $nv_tegra_date, replacing with $target_file"
      if [ ! -f "$target_file" ]; then
        echoerr "$target_file does not exist"
        exit 1
      fi
      safe_cp "$target_file" "$file"
    fi
  fi
done

# Create device tree overlay files
# https://developer.ridgerun.com/wiki/index.php/NVIDIA_Jetson_-_Device_Tree_Overlay
# https://docs.nvidia.com/jetson/archives/r34.1/DeveloperGuide/text/HR/ConfiguringTheJetsonExpansionHeaders.html#running-jetson-io
if [[ -f $overlay_file_ ]]; then
  args_+=(1="$(grep -oP 'overlay-name = "\K[^"]+' $overlay_file_)") # assumes its part of 40 pin header
  cpp -nostdinc -I "/usr/src/linux-headers-$(uname -r)-ubuntu20.04_aarch64/kernel-5.10/include/" \
    -undef -x assembler-with-cpp $overlay_file_ /tmp/$overlay_name_.dtsi.pp
  dtc -O dtb -o /boot/tegra234-p3737-$overlay_name_.dtbo -@ /tmp/$overlay_name_.dtsi.pp
  echoinfo "found overlay file $overlay_file_"
fi
# Form a NOVA device tree
echoinfo "/opt/nvidia/jetson-io/config-by-hardware.py ${args_[@]}"
/opt/nvidia/jetson-io/config-by-hardware.py "${args_[@]}"
