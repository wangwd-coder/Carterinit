#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
from argparse import ArgumentParser
import json
import socket


def update_calibration(file, dry_run=False):
    """Update calibration file.

    Args:
        file (str): File to update.
        dry_run (bool): Flag to output to console instead of writing over file.
    """
    host = socket.gethostname()
    with open(file, "r") as f:
        data = json.load(f)
    data["calibration"]["platform"]["name"] = host
    if dry_run:
        print(json.dumps(data, indent=4))
        return
    with open(file, "w") as file:
        json.dump(data, file, indent=4)


def main():
    parser = ArgumentParser()
    default_file = "/etc/nova/calibration/isaac_calibration.json"
    parser.add_argument("-f",
                        "--file",
                        type=str,
                        default=default_file,
                        help=f"Path to calibration file.")
    parser.add_argument("-n",
                        "--dry-run",
                        action="store_true",
                        help="Outputs results without writing.")
    args = parser.parse_args()
    update_calibration(args.file, args.dry_run)


if __name__ == "__main__":
    main()
