#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Sets up wallpaper
set -e
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/consts.sh
old_background="$($PRE_CMD gsettings get org.gnome.desktop.background picture-uri)"
old_background="$(rm_quotes $old_background \')"
echo "$old_background" >$SCRIPT_DIR/old_background.txt
$PRE_CMD gsettings set org.gnome.desktop.background picture-uri "$NOVA_BACKGROUND"
