#!/usr/bin/python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################

from enum import auto, Enum


def camel_to_snake(str: str):
    """Converts camel case string to snake case"""
    res = str[0].lower()
    for c in str[1:]:
        if c.isupper() or c.isdigit():
            res += '_'
            res += c.lower()
        else:
            res += c
    return ''.join(res)


#!NOTE: CHANGES TO THE DATACLASSES HERE MUST BE REFLECTED IN NVIDIA ISAAC REPO
class NovaChannels(Enum):
    kError = -1
    kFrontStereoCamera = 0
    kRearStereoCamera = auto()
    kLeftStereoCamera = auto()
    kRightStereoCamera = auto()
    kFrontDepthCamera = auto()
    kRearDepthCamera = auto()
    kFront3dLidar = auto()
    kFrontStereoImu = auto()
    kRearStereoImu = auto()
    kDrivetrain = auto()
    kChassisImu = auto()
    kFront2dLidar = auto()
    kBack2dLidar = auto()
    kFrontFisheyeCamera = auto()
    kRearFisheyeCamera = auto()
    kLeftFisheyeCamera = auto()
    kRightFisheyeCamera = auto()

    @property
    def snake_name(self):
        return camel_to_snake(self.name[1:])


# Maps ID X to argus module name HAWKX
HAWK_ID_MAP = {
    NovaChannels.kFrontStereoCamera: 1,
    NovaChannels.kRearStereoCamera: 2,
    NovaChannels.kRightStereoCamera: 4,
    NovaChannels.kLeftStereoCamera: 3,
}
