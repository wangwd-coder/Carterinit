#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
import glob
import os
from pathlib import Path
from packaging import version as pversion
import pytest
import re
import subprocess
from nova_init.tests.utils import CameraType, reduceidfn, switch_operand


def get_matched_camera_devices(pattern):
    """Gets all camera devices with matching regex naming pattern. Looks at the /sys/**/name
    folder related to the device for matching.

    Args:
        pattern (string): regex pattern for matching name

    Returns:
        List[string]: List of all /dev/video* devices with matching camera.
    """
    devices = glob.glob("/dev/video*")
    matched_devices = []
    for dev_file in devices:
        out = subprocess.check_output(["udevadm", "info", dev_file])
        info_data = out.decode('utf-8')
        match = re.search("P: (.*)\n", info_data)
        if not match:
            continue
        sys_name_path = Path("/sys", match.groups()[0].lstrip("/"), "name")
        if not sys_name_path.exists():
            continue
        with open(sys_name_path.resolve()) as f:
            sys_name = f.read()
        if re.fullmatch(pattern, sys_name):
            matched_devices.append(dev_file)
    return matched_devices


def get_matched_imus(pattern):
    """Gets all IMU devices with matching regex naming pattern. Looks at the /sys/**/name
    file related to the device for matching.

    Args:
        pattern (string): regex pattern for matching name

    Returns:
        List[string]: List of all device folders with IMU component.
    """
    imus = glob.glob("/sys/bus/iio/devices/iio:device*")
    matched_imus = []
    for dev_folder in imus:
        dev_name_path = Path(dev_folder, "name")
        if not dev_name_path.exists():
            continue
        with open(dev_name_path.resolve()) as f:
            dev_name = f.read()
        if re.fullmatch(pattern, dev_name):
            matched_imus.append(dev_folder)
    return matched_imus


def get_bmi_device_pairs():
    """Finds all bmi088 device pairs, looks at /sys/bus/iio/devices/ and returns a list of tuples
    with the matching (accel_idx, gyro_idx)

    Args: None

    Returns: Dict[int: Tuple(int)]: dictionary mapping bmi id's numbers to tuples with matched device
    indices, for example
    {69: (imu0_accel_idx, imu0_gyro_idx), 68: (imu1_accel_idx, imu1_gyro_idx)}

    The accel index is always first then gyro
    """
    id_to_index_tuple = {}
    bmi_devices = get_matched_imus(r'accelerometer\n|gyroscope\n')
    for bmi_dev in bmi_devices:
        of_node = os.path.realpath(bmi_dev + "/of_node")
        last_at_index = of_node.rfind('@')
        assert last_at_index, f"Found IMU without expected i2c bus format at {real_path}"
        bmi_id = int(of_node[last_at_index + 1:])

        match_device = re.search(r'device(\d+)$', bmi_dev)
        assert match_device, f"Found IMU without expected device format at {real_path}"

        device_idx = int(match_device.group(1))

        if bmi_id not in id_to_index_tuple:
            id_to_index_tuple[bmi_id] = [None, None]

        dev_name = open(f"{bmi_dev}/name").read()
        if "accelerometer" in dev_name:
            id_to_index_tuple[bmi_id][0] = device_idx
        elif "gyroscope" in dev_name:
            id_to_index_tuple[bmi_id][1] = device_idx

    return id_to_index_tuple


FS_CAMERA_MAP = {
    CameraType.HAWK: (r"vi-output, ar0234 (9|10|30|31)-\d{4}\n", 2),
    CameraType.REALSENSE: (r"Intel\(R\) RealSense\(TM\) Depth Ca\n", 6),
    CameraType.OWL: (r"vi-output, ar0234 2-\d{4}\n", 1),
}

FS_IMU_MAP = {
    CameraType.HAWK: r"(accelerometer|gyroscope)\n",
    CameraType.REALSENSE: r"(accel_3d|gyro_3d)\n",
}


def test_filesystem_ssd():
    ssd_dir = "/mnt/nova_ssd"
    resp = subprocess.call(["mountpoint", "-q", ssd_dir],
                           stdout=subprocess.DEVNULL,
                           stderr=subprocess.STDOUT)
    assert resp == False, f"SSD is not mounted on \"{ssd_dir}\""


FS_DEV_PARAMS = [
    ("/dev/ptp0"),
    ("/dev/nvpps0"),
    ("/dev/rtc0"),
]


@pytest.mark.parametrize("dev", FS_DEV_PARAMS)
def test_filesystem_dev(dev):
    assert Path(dev).is_char_device(), f"Char device {dev} does not exist"


FS_IMU_PARAMS = []


@pytest.mark.parametrize("imu,exp_imus", FS_IMU_PARAMS, ids=reduceidfn)
def test_filesystem_imu(imu, exp_imus):
    assert imu in FS_IMU_MAP, "Imu not mapped with pattern."
    pattern = FS_IMU_MAP[imu]
    imus = get_matched_imus(pattern)
    num_imus = len(imus) / 2
    assert num_imus == exp_imus, f"Not enough IMUs. Found {num_imus}"


FS_CAMERA_PARAMS = []


@pytest.mark.parametrize("camera,exp_cams", FS_CAMERA_PARAMS, ids=reduceidfn)
def test_filesystem_camera(camera, exp_cams):
    assert camera in FS_CAMERA_MAP, "Camera not mapped with pattern."
    pattern, feeds_per_cam = FS_CAMERA_MAP[camera]
    devices = get_matched_camera_devices(pattern)
    assert len(devices) % feeds_per_cam == 0, \
        f"Number of devices isn't a multiple of the expected number of feeds " + \
        f"on a camera {feeds_per_cam}. Found {len(devices)} devices."
    assert len(devices) / feeds_per_cam == exp_cams, f"Not enough cameras. Found {len(devices)}"


@pytest.mark.parametrize("exe,version_op", [("wpa_supplicant", "2.9.1_nv")])
def test_exe_version(exe, version_op):
    out = subprocess.check_output([exe, "-v"]).decode('utf-8')
    operand_m = re.search(r'[<>!=]+', version_op)
    operand = operand_m.group() if operand_m else ""
    version_m = re.search(r"(\d+\.\d+(?:\.\d+)*)", version_op)
    assert version_m, f"no version found in test input: {version_op}"
    version = version_m.group()
    exe_ver_m = re.search(r"(\d+\.\d+(?:\.\d+)*)", out)
    assert exe_ver_m, f"no version found in command output: {out}"
    exe_ver = exe_ver_m.group()
    if operand == "":
        assert exe_ver == version, f"{exe_ver} does not match {version}"
    else:
        left, right = pversion.parse(exe_ver), pversion.parse(version)
        assert switch_operand(operand, left, right), f"{left} {operand} {right} is invalid or" \
            "unsupported"
