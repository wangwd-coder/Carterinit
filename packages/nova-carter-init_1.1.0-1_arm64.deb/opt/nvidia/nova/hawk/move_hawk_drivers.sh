#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Script to safely modify HAWK ko files and restore them
# Example usage:
#  ./modify_hawk_drivers.sh -m -i ~/  nv_ar0234.ko max96712.ko  # modify
#  ./modify_hawk_drivers.sh -r nv_ar0234.ko max96712.ko  # restore
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

usage="
$(basename "$0") [-h] [-m] [-r] [-i i] FILE FILE ... -- move HAWK ko files safely

where:
    -h  show this help text
    -m  modifies the HAWK ko files in place
    -r  restores the HAWK ko files if a backup exists
    -i  input directory where ko files to insert are  (defaults to: PWD)
"

cwd=$PWD
list=()
flag=""
ko_dir="/lib/modules/$(uname -r)/kernel/drivers/media/i2c"

modify_ko() {
  ko=$1
  if [ ! -f $ko_dir/$ko ]; then
    echoerr "$ko_dir/$ko file doesn't exist"
    exit 1
  fi
  if [ -f $ko_dir/$ko.bak ]; then
    echoerr "Backup file $ko_dir/$ko.bak exist"
    exit 2
  fi
  if [ ! -f $cwd/$ko ]; then
    echoerr "File to modify with $cwd/$ko doesn't exist"
    exit 3
  fi
  sudo cp $ko_dir/$ko $ko_dir/$ko.bak
  sudo cp $cwd/$ko $ko_dir/
}

restore_ko() {
  ko=$1
  if [ ! -f $ko_dir/$ko.bak ]; then
    echoerr "Backup file for $ko_dir/$ko.bak doesn't exist"
    exit 1
  fi
  sudo mv $ko_dir/$ko.bak $ko_dir/$ko
}

# Parse command-line options
while getopts ":hrmi:" opt; do
  case $opt in
    h)
      echo "$usage"
      exit
      ;;
    r)
      mode="restore_ko"
      ;;
    m)
      mode="modify_ko"
      ;;
    i)
      cwd=$OPTARG
      if [ ! -d $cwd ]; then
        echoerr "$cwd is not a directory"
        exit 1
      fi
      ;;
    \?)
      echoerr "Invalid option: -$OPTARG"
      echo "$usage" 1>&2
      exit 1
      ;;
  esac
done

# Shift the parsed options
shift $((OPTIND - 1))

if [ -z "$mode" ]; then
  echoerr "no mode passed"
  exit 1
fi
if ((${#a[@]})); then
  echoerr "no files passed"
  exit 1
fi
for item in "$@"; do
  eval "$mode $item"
done
