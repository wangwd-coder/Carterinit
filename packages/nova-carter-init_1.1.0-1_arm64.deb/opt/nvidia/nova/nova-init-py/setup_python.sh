#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Sets up a venv and installs the nova-init python package + installs dependecies

SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
python3 -m venv $SCRIPT_DIR/venv
source $SCRIPT_DIR/venv/bin/activate
pip install -e $SCRIPT_DIR
pip install -r $SCRIPT_DIR/requirements.txt
