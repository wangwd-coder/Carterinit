#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Utilities for logging
### Terminal colors ###
YELLOW="\033[0;33m"
RED="\033[0;31m"
GREEN="\033[0;32m"
ENDCOLOR="\033[0m"
BOLD="\033[1m"
ENDBOLD="\033[22m"
echobold() { echo -e $BOLD"$@"$ENDBOLD; }
echoerr() { echo -e $RED"ERROR: $@"$ENDCOLOR 1>&2; }
echowarn() { echo -e $YELLOW"WARN: $@"$ENDCOLOR 1>&2; }
echoinfo() { echo -e $GREEN"INFO: $@"$ENDCOLOR 1>&2; }
