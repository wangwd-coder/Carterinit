#!/usr/bin/env python3
##############################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.               #
#                                                                            #
# NVIDIA CORPORATION and its licensors retain all intellectual property      #
# and proprietary rights in and to this software, related documentation      #
# and any modifications thereto. Any use, reproduction, disclosure or        #
# distribution of this software and related documentation without an express #
# license agreement from NVIDIA CORPORATION is strictly prohibited.          #
##############################################################################
import json
import os
import socket
import pytest


@pytest.mark.calibration
def test_calibration_host():
    file = "/etc/nova/calibration/isaac_calibration.json"
    assert os.path.isfile(file), f"{file} is not  a file"
    with open(file, "r") as f:
        data = json.load(f)
    host = socket.gethostname()
    cal_host = data["calibration"]["platform"]["name"]
    assert host == cal_host, f"Hostname in calibration is not the same as machine. Calibration host: {cal_host}. Machine host: {host}."
