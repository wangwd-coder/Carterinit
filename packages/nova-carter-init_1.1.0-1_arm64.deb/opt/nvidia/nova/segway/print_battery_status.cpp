/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <cstdio>
#include "comm_ctrl_navigation.h"

int main(int argc, char** argv) {
  set_comu_interface(comu_can);
  if (init_control_ctrl() == -1) {
    printf("ERROR: couldn't initialize control interface with segway");
    return 1;
  }
  printf("\nbattery: %d%%\n\n", get_bat_soc());
  exit_control_ctrl();
}
