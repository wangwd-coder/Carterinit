#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Constant variables for the wallpaper
set -e
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
NOVA_BACKGROUND="file://${SCRIPT_DIR}/nova-carter-wallpaper.png"

# pre-command that runs before any command, needed for processes that interact with the user space
# https://www.reddit.com/r/pop_os/comments/yb1q39/setting_a_gsettings_parameter_as_root_fails/
PRE_CMD=""
if [ ! -z $SUDO_UID ]; then
  PRE_CMD="sudo -u $SUDO_USER DISPLAY=:0 DBUS_SESSION_BUS_ADDRESS=unix:path=/run/user/$SUDO_UID/bus"
fi

# removes surrounding characters around string
rm_quotes() {
  opt=$1
  char=$2
  temp="${opt%$char}"
  temp="${temp#$char}"
  echo $temp
}
