/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include "cxxopts.hpp"
#include "yaml-cpp/yaml.h"

#include <Argus/Argus.h>
#include "Argus/Ext/SyncSensorCalibrationData.h"

#include "hawk_eeprom.h"
#include "hawk_utils.h"

#define MAX_MODULE_STRING 32

using namespace Argus;

void map_argus_to_cam_intr(
    const Ext::ISyncSensorCalibrationData* camera_data, camera_intrinsics& intr) {
  Size2D<uint32_t> image_size = camera_data->getImageSizeInPixels();
  intr.height = image_size.height();
  intr.width = image_size.width();
  Point2D<float> focal_length = camera_data->getFocalLength();
  intr.fx = focal_length.x();
  intr.fy = focal_length.y();
  intr.skew = camera_data->getSkew();
  Point2D<float> principal_point = camera_data->getPrincipalPoint();
  intr.cx = principal_point.x();
  intr.cy = principal_point.y();
  DistortionType lens_distortion_type = camera_data->getLensDistortionType();
  if (lens_distortion_type == DISTORTION_TYPE_POLYNOMIAL) {
    intr.distortion_type = 0;
    uint32_t radial_coeffs_count = camera_data->getRadialCoeffsCount(lens_distortion_type);
    intr.dist_coeff.poly.radial_coeff_count = radial_coeffs_count;
    std::vector<float> k;
    camera_data->getRadialCoeffs(&k, lens_distortion_type);
    for (uint32_t idx = 0; idx < k.size(); idx++) {
      intr.dist_coeff.poly.k[idx] = k[idx];
    }
    uint32_t tangential_coeffs_count = camera_data->getTangentialCoeffsCount();
    intr.dist_coeff.poly.tangential_coeff_count = tangential_coeffs_count;
    std::vector<float> p;
    camera_data->getTangentialCoeffs(&p);
    for (uint32_t idx = 0; idx < p.size(); idx++) {
      intr.dist_coeff.poly.p[idx] = p[idx];
    }
  } else if (lens_distortion_type == DISTORTION_TYPE_FISHEYE) {
    intr.distortion_type = 1;
    uint32_t radial_coeffs_count = camera_data->getRadialCoeffsCount(lens_distortion_type);
    intr.dist_coeff.fisheye.coeff_count = radial_coeffs_count;
    std::vector<float> k;
    camera_data->getRadialCoeffs(&k, lens_distortion_type);
    for (uint32_t idx = 0; idx < k.size(); idx++) {
      intr.dist_coeff.fisheye.k[idx] = k[idx];
    }
    MappingType fish_mapping_type = camera_data->getFisheyeMappingType();
    if (fish_mapping_type == MAPPING_TYPE_EQUIDISTANT) {
      intr.dist_coeff.fisheye.mapping_type = 0;
    } else if (fish_mapping_type == MAPPING_TYPE_EQUISOLID) {
      intr.dist_coeff.fisheye.mapping_type = 1;
    } else if (fish_mapping_type == MAPPING_TYPE_ORTHOGRAPHIC) {
      intr.dist_coeff.fisheye.mapping_type = 2;
    } else if (fish_mapping_type == MAPPING_TYPE_STEREOGRAPHIC) {
      intr.dist_coeff.fisheye.mapping_type = 3;
    }
  } else if (lens_distortion_type == DISTORTION_TYPE_OMINI_DIRECTIONAL) {
    intr.distortion_type = 2;
  }
}

void map_argus_to_extr(
    const Point3D<float>& rot3d, const Point3D<float>& translation, camera_extrinsics& extr) {
  extr.rx = rot3d.x();
  extr.ry = rot3d.y();
  extr.rz = rot3d.z();
  extr.tx = translation.x();
  extr.ty = translation.y();
  extr.tz = translation.z();
}

void map_argus_to_imu(
    const Ext::ISyncSensorCalibrationData* camera_data, imu_params_v1& imu,
    imu_params_noise_m& nm) {
  bool is_imu = camera_data->isImuSensorAvailable();
  if (is_imu) {
    Point3D<float> linear_acc_bias = camera_data->getLinearAccBias();
    imu.linear_acceleration_bias[0] = linear_acc_bias.x();
    imu.linear_acceleration_bias[1] = linear_acc_bias.y();
    imu.linear_acceleration_bias[2] = linear_acc_bias.z();
    Point3D<float> angular_velocity_bias = camera_data->getAngularVelocityBias();
    imu.angular_velocity_bias[0] = angular_velocity_bias.x();
    imu.angular_velocity_bias[1] = angular_velocity_bias.y();
    imu.angular_velocity_bias[2] = angular_velocity_bias.z();
    Point3D<float> gravity_acc = camera_data->getGravityAcc();
    imu.gravity_acceleration[0] = gravity_acc.x();
    imu.gravity_acceleration[1] = gravity_acc.y();
    imu.gravity_acceleration[2] = gravity_acc.z();
    map_argus_to_extr(
        camera_data->getImuRotationParams(), camera_data->getImuTranslationParams(), imu.extr);
    nm.update_rate = camera_data->getUpdateRate();
    nm.linear_acceleration_noise_density = camera_data->getLinearAccNoiseDensity();
    nm.linear_acceleration_random_walk = camera_data->getLinearAccRandomWalk();
    nm.angular_velocity_noise_density = camera_data->getAngularVelNoiseDensity();
    nm.angular_velocity_random_walk = camera_data->getAngularVelRandomWalk();
  }
}

static void map_argus_to_liee(
    const Ext::ISyncSensorCalibrationData* left_cam,
    const Ext::ISyncSensorCalibrationData* right_cam, hawk_eeprom_struct& liee) {
  // NOTE: setting the version and factory data to assumed version based on struct used
  liee.version = 1;
  liee.factory_data = 0;
  map_argus_to_cam_intr(left_cam, liee.left_cam_intr);
  map_argus_to_cam_intr(right_cam, liee.right_cam_intr);
  map_argus_to_extr(left_cam->getRotationParams(), left_cam->getTranslationParams(), liee.cam_extr);
  liee.imu_present = left_cam->isImuSensorAvailable();
  map_argus_to_imu(left_cam, liee.imu, liee.nm);
  left_cam->getModuleSerialNumber(liee.serial_number, sizeof(liee.serial_number));
}

int get_liee_from_argus(hawk_eeprom_struct& liee, uint index) {
  Argus::UniqueObj<Argus::CameraProvider> camera_provider;
  std::vector<Argus::CameraDevice*> camera_devices;

  Argus::Status status = Argus::STATUS_OK;
  camera_provider.reset(Argus::CameraProvider::create(&status));
  if (status != Argus::STATUS_OK) {
    spdlog::error("no provider");
    return -1;
  }

  Argus::ICameraProvider* i_camera_provider =
      Argus::interface_cast<Argus::ICameraProvider>(camera_provider.get());
  if (!i_camera_provider) {
    spdlog::error("no iprovider");
    return -1;
  }

  // Get the camera devices.
  status = i_camera_provider->getCameraDevices(&camera_devices);
  if (status != Argus::STATUS_OK) {
    spdlog::error("failed to get camera devices");
    return -1;
  }

  char sensor_id_ptr[MAX_MODULE_STRING];
  uint count = 0;
  int left_cam_idx = -1;
  for (uint32_t i = 0; i < camera_devices.size(); i++) {
    const Argus::Ext::ISyncSensorCalibrationData* i_sync_sensor_calibration_data =
        Argus::interface_cast<const Argus::Ext::ISyncSensorCalibrationData>(camera_devices[i]);
    if (!i_sync_sensor_calibration_data) {
      continue;
    }
    i_sync_sensor_calibration_data->getSyncSensorModuleId(sensor_id_ptr, sizeof(sensor_id_ptr));
    std::string sensor_id(sensor_id_ptr);
    std::string match = "HAWK" + std::to_string(index);
    spdlog::debug("Processing {}", sensor_id);
    if (sensor_id != match) {
      continue;
    }
    if (count == 0 && left_cam_idx < 0) {
      left_cam_idx = i;
    } else if (count == 1 && left_cam_idx >= 0) {
      const Argus::Ext::ISyncSensorCalibrationData* left_cal_data =
          Argus::interface_cast<const Argus::Ext::ISyncSensorCalibrationData>(
              camera_devices[left_cam_idx]);
      if (!i_sync_sensor_calibration_data) {
        spdlog::error("Couldn't re-get left camera calibration data");
        return -1;
      }
      map_argus_to_liee(left_cal_data, i_sync_sensor_calibration_data, liee);
    } else if (count >= 2 && left_cam_idx >= 0) {
      spdlog::error("Found more than two cameras in stereo camera");
      return -1;
    }
    count++;
  }
  if (count != 2) {
    spdlog::error("Processed {} sub cameras for hawk, expected 2", count);
    return -1;
  }
  return 0;
}

YAML::Node get_poly_yaml(const polynomial_lens_distortion_coeff& poly) {
  YAML::Node yaml;
  yaml["radial_coeff_count"] = poly.radial_coeff_count;
  yaml["k"][0] = poly.k[0];
  yaml["k"][1] = poly.k[1];
  yaml["k"][2] = poly.k[2];
  yaml["k"][3] = poly.k[3];
  yaml["k"][4] = poly.k[4];
  yaml["k"][5] = poly.k[5];
  yaml["tangential_coeff_count"] = poly.tangential_coeff_count;
  yaml["p"][0] = poly.p[0];
  yaml["p"][1] = poly.p[1];
  return yaml;
}

YAML::Node get_fisheye_yaml(const fisheye_lens_distortion_coeff& fisheye) {
  YAML::Node yaml;
  yaml["coeff_count"] = fisheye.coeff_count;
  yaml["k"][0] = fisheye.k[0];
  yaml["k"][1] = fisheye.k[1];
  yaml["k"][2] = fisheye.k[2];
  yaml["k"][3] = fisheye.k[3];
  yaml["k"][4] = fisheye.k[4];
  yaml["k"][5] = fisheye.k[5];
  yaml["mapping_type"] = fisheye.mapping_type;
  return yaml;
}

YAML::Node get_cam_intr_yaml(const camera_intrinsics& intr) {
  YAML::Node yaml;
  yaml["width"] = intr.width;
  yaml["height"] = intr.height;
  yaml["fx"] = intr.fx;
  yaml["fy"] = intr.fy;
  yaml["skew"] = intr.skew;
  yaml["cx"] = intr.cx;
  yaml["cy"] = intr.cy;
  yaml["distortion_type"] = intr.distortion_type;
  if (intr.distortion_type == 0) {
    yaml["dist_coeff"]["poly"] = get_poly_yaml(intr.dist_coeff.poly);
  } else if (intr.distortion_type == 1) {
    yaml["dist_coeff"]["fisheye"] = get_fisheye_yaml(intr.dist_coeff.fisheye);
  }
  return yaml;
}

YAML::Node get_extr_yaml(const camera_extrinsics& extr) {
  YAML::Node yaml;
  yaml["rx"] = extr.rx;
  yaml["ry"] = extr.ry;
  yaml["rz"] = extr.rz;
  yaml["tx"] = extr.tx;
  yaml["ty"] = extr.ty;
  yaml["tz"] = extr.tz;
  return yaml;
}

YAML::Node get_imu_yaml(const imu_params_v1& imu) {
  YAML::Node yaml;
  yaml["linear_acceleration_bias"][0] = imu.linear_acceleration_bias[0];
  yaml["linear_acceleration_bias"][1] = imu.linear_acceleration_bias[1];
  yaml["linear_acceleration_bias"][2] = imu.linear_acceleration_bias[2];
  yaml["angular_velocity_bias"][0] = imu.angular_velocity_bias[0];
  yaml["angular_velocity_bias"][1] = imu.angular_velocity_bias[1];
  yaml["angular_velocity_bias"][2] = imu.angular_velocity_bias[2];
  yaml["gravity_acceleration"][0] = imu.gravity_acceleration[0];
  yaml["gravity_acceleration"][1] = imu.gravity_acceleration[1];
  yaml["gravity_acceleration"][2] = imu.gravity_acceleration[2];
  yaml["extr"] = get_extr_yaml(imu.extr);
  return yaml;
}

YAML::Node get_nm_yaml(const imu_params_noise_m& nm) {
  YAML::Node yaml;
  yaml["update_rate"] = nm.update_rate;
  yaml["linear_acceleration_noise_density"] = nm.linear_acceleration_noise_density;
  yaml["linear_acceleration_random_walk"] = nm.linear_acceleration_random_walk;
  yaml["angular_velocity_noise_density"] = nm.angular_velocity_noise_density;
  yaml["angular_velocity_random_walk"] = nm.angular_velocity_random_walk;
  return yaml;
}

int create_lieeprom_yaml(hawk_eeprom_struct& liee, YAML::Node& yaml) {
  yaml["version"] = liee.version;
  yaml["factory_data"] = liee.factory_data;

  yaml["left_cam_intr"] = get_cam_intr_yaml(liee.left_cam_intr);
  yaml["right_cam_intr"] = get_cam_intr_yaml(liee.right_cam_intr);
  yaml["cam_extr"] = get_extr_yaml(liee.cam_extr);

  yaml["imu_present"] = liee.imu_present;
  yaml["imu"] = get_imu_yaml(liee.imu);

  liee.serial_number[8] = '\0';  // Garbage values in 9th and 10th byte, override so string exits
  yaml["serial_number"] = std::string(reinterpret_cast<char*>(liee.serial_number));

  yaml["nm"] = get_nm_yaml(liee.nm);
  return 0;
}

int get_liee_from_i2c(hawk_eeprom_struct& liee, int i2c_bus) {
  int fd;
  if (get_i2c_fd(fd, i2c_bus, O_RDONLY)) {
    return -1;
  }
  eeprom_read(fd, EEPROM_ADDRESS, 0x00, reinterpret_cast<u_char*>(&liee), sizeof(liee));
  close(fd);
  return 0;
}

int main(int argc, char** argv) {
  cxxopts::Options options(
      "print_eeprom",
      "Prints the contents of a Leopard Imaging Hawk camera EEPROM as human readable yaml.");
  options.positional_help("<index>");
  options.add_options()("index", "Index of hawk. Starts at 1.", cxxopts::value<uint>())(
      "n,dry-run", "Outputs the file contents to the command line instead of a yaml.",
      cxxopts::value<bool>()->default_value("false"))(
      "f,file", "File name", cxxopts::value<std::string>()->default_value("/tmp/liee.yaml"))(
      "c,use-i2c", "Use i2c buses.", cxxopts::value<bool>()->default_value("false"))(
      "v,verbose", "Verbose output. Prints raw eeprom binary.",
      cxxopts::value<bool>()->default_value("false"))("h,help", "Print usage");
  options.parse_positional({"index"});
  auto result = options.parse(argc, argv);
  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    exit(0);
  }
  bool verbose = result["verbose"].as<bool>();
  bool dry_run = result["dry-run"].as<bool>();
  bool use_i2c = result["use-i2c"].as<bool>();
  auto file = result["file"].as<std::string>();
  auto index = result["index"].as<uint>();

  if (verbose) {
    spdlog::set_level(spdlog::level::debug);
  }

  hawk_eeprom_struct liee;
  int ret = 0;
  if (use_i2c) {
    static int i2c_buses[2] = {30, 31};
    int size = sizeof(i2c_buses) / sizeof(i2c_buses[0]);
    uint zero_index = index - 1;
    if (zero_index >= size) {
      spdlog::error("Hawk index not supported, only %d i2cs mapped\n", size);
      return -1;
    }
    ret = get_liee_from_i2c(liee, i2c_buses[zero_index]);
  } else {
    ret = get_liee_from_argus(liee, index);
  }
  if (ret < 0) {
    spdlog::error("Errored while getting data\n");
    return ret;
  }
  YAML::Node yaml;
  if (create_lieeprom_yaml(liee, yaml) < 0) return -1;
  if (verbose || dry_run) spdlog::info("----------------YAML EEPROM------------------\n{}", yaml);
  if (!dry_run) {
    std::ofstream fout(file.c_str());
    fout << yaml;
  }
}
