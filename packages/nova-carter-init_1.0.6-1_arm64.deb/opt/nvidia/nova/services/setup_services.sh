#! /bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Enables all services that debian package installs
SCRIPT_DIR="$(builtin cd "$(dirname "${BASH_SOURCE[0]}")" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh
systemctl daemon-reload # reloads service tree
IFS=$'\n'
for file in $NOVA_INSTALLED_SERVICES; do
  if [ ! -f $file ]; then
    continue
  fi
  service=$(basename $file)
  sudo systemctl enable $service
done
unset IFS
sudo udevadm control --reload-rules && udevadm trigger
