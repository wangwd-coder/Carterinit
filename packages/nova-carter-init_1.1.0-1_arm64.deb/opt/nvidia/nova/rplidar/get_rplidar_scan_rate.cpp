/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <spdlog/spdlog.h>
#include <chrono>
#include <iostream>
#include "cxxopts.hpp"
#include "sl_lidar.h"
#include "sl_lidar_driver.h"

using namespace sl;
int main(int argc, char** argv) {
  cxxopts::Options options(
      "get_rplidar_scan_rate", "Gets an RPLIDARs scan rate and prints it to screen.");
  options.positional_help("<ip>");
  options.add_options()("ip", "Current IP of RPLIDAR", cxxopts::value<std::string>())(
      "t,time", "Time to run scan in seconds.", cxxopts::value<int64_t>()->default_value("20"))(
      "h,help", "Print usage");
  options.parse_positional({"ip"});
  auto result = options.parse(argc, argv);
  if (result.count("help")) {
    std::cout << options.help() << std::endl;
    exit(0);
  }
  auto ip = result["ip"].as<std::string>();
  std::chrono::seconds scan_time(result["time"].as<int64_t>());
  std::unique_ptr<IChannel> channel(*createUdpChannel(ip, 8089));
  std::unique_ptr<ILidarDriver> lidar(*createLidarDriver());
  auto res = lidar->connect(channel.get());
  if (SL_IS_OK(res)) {
    sl::LidarScanMode mode;
    float freq_sum = 0.0;
    auto start = std::chrono::steady_clock::now();
    size_t calls = 0;
    lidar->startScan(0, 1, 0, &mode);
    while (std::chrono::steady_clock::now() - start < scan_time) {
      sl_lidar_response_measurement_node_hq_t nodes[8192];
      size_t sz = sizeof(nodes) / sizeof(nodes[0]);
      float freq = 0.0;
      res = lidar->grabScanDataHq(nodes, sz);
      if (!SL_IS_OK(res)) {
        spdlog::error("Current lidar IP address {} won't communicate, exiting...", ip);
        exit(1);
      }
      res = lidar->getFrequency(mode, nodes, sz, freq);
      if (!SL_IS_OK(res)) {
        spdlog::error("Couldn't get frequency");
        exit(1);
      }
      freq_sum += freq;
      calls++;
    };
    printf("scan_rate: %f\n", freq_sum / calls);
    lidar->stop();
  } else {
    spdlog::error("Failed to connect to lidar {}...", ip);
    exit(1);
  }
}
