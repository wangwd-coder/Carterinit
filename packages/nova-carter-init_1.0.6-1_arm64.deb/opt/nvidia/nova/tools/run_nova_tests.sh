#!/bin/bash
#####################################################################################
# Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

# NVIDIA CORPORATION and its licensors retain all intellectual property
# and proprietary rights in and to this software, related documentation
# and any modifications thereto. Any use, reproduction, disclosure or
# distribution of this software and related documentation without an express
# license agreement from NVIDIA CORPORATION is strictly prohibited.
#####################################################################################
# Activate env and run python tests
SCRIPT_DIR="$(builtin cd "$(dirname $(readlink -f "${BASH_SOURCE[0]}"))" >/dev/null && pwd)"
source $SCRIPT_DIR/../exit.sh
source $SCRIPT_DIR/../utils.sh

source $SCRIPT_DIR/../nova-init-py/venv/bin/activate
sudo -E env PATH=$PATH pytest $SCRIPT_DIR/../nova-init-py/nova_init/tests/test_carter_v$NOVA_ROBOT_MAJORV$NOVA_ROBOT_MINORV.py $@
