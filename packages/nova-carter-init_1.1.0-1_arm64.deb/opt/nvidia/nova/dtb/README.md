# Debugging

`fdtdump` can be used to quickly print a dtb file and its contents.

# Writing DTBO files

Symbol references found in the `__symbols__` sections in the main dtb can be used in overlay files
by addressing their memory with `&<symbol>`.
