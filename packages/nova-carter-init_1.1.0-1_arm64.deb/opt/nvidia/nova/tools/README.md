# Tools

## HAWK IMU

To determine if the device is a hawk or realsense IMU run the following command replacing \<N\> with the device number:

```bash
cat /sys/bus/iio/devices/iio\:device<N>/name
```

If the device name contains `_3d` it is realsense.

To test the IMUs run below, replacing \<N\> with the hawk devices:

```bash
cd /opt/nvidia/nova/tools/hawk
./iio_generic_buffer -N <N> -g -A -c 100
```

To quickly check if the hawk cameras visible on the device run:

```bash
cd /opt/nvidia/nova/tools/hawk
./v4l2-ctl --list-devices
```

You should see an output like:

```
vi-output, ar0234 30-0018 (platform:tegra-capture-vi:1):
        /dev/video20
        /dev/video21
        /dev/video22
        /dev/video23
        /dev/v4l-subdev7
        /dev/v4l-subdev0
        /dev/v4l-subdev1
        /dev/v4l-subdev2
        /dev/v4l-subdev3
        /dev/v4l-subdev4
        /dev/v4l-subdev5
        /dev/v4l-subdev6
```

## Segway

This tool `ctrl_arm64-v8a` is an exe to test, flash, and inspect the segway.

To test the segway with it run:

```bash
cd /opt/nvidia/nova/tools/segway/
sudo ./ctrl_arm64-v8a c -test central
sudo ./ctrl_arm64-v8a c -test heart_beat
```
