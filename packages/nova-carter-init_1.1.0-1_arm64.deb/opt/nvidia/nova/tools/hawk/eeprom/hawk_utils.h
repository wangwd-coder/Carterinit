/*
Copyright (c) 2023, NVIDIA CORPORATION. All rights reserved.

NVIDIA CORPORATION and its licensors retain all intellectual property
and proprietary rights in and to this software, related documentation
and any modifications thereto. Any use, reproduction, disclosure or
distribution of this software and related documentation without an express
license agreement from NVIDIA CORPORATION is strictly prohibited.
*/
#include <fcntl.h>
#include <linux/i2c.h>
#include <linux/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ioctl.h>
#include <sys/types.h>
#include <unistd.h>
#include <string>

#include <linux/i2c-dev.h>
#include <spdlog/spdlog.h>
#define SPDLOG_FMT_EXTERNAL   // Enable external formatting
#include <spdlog/fmt/ostr.h>  // Include this for ostream operator<< support for YAML types

#define EEPROM_ADDRESS 0x54

int read_register_byte(int fd, __u8 addr, __u8 offset_addr, __u8* ret_val) {
  struct i2c_msg i2c_msg = {0};
  struct i2c_rdwr_ioctl_data i2cdev_data = {0};
  struct i2c_msg msgs[2] = {0};
  __u8 buf[3] = {0x00};
  __u8 buf_r[3] = {0x00};
  int ret = 0;

  buf[0] = offset_addr;

  // read register
  msgs[0].addr = addr;
  msgs[0].flags = 0;  // write
  msgs[0].len = 1;
  msgs[0].buf = buf;

  msgs[1].addr = addr;
  msgs[1].flags |= I2C_M_RD;
  msgs[1].len = 1;
  msgs[1].buf = buf_r;

  i2cdev_data.nmsgs = 2;
  i2cdev_data.msgs = msgs;

  ret = ioctl(fd, I2C_RDWR, &i2cdev_data);
  if (ret < 0) {
    spdlog::error("ioctl failed to read");
    return ret;
  }
  (*ret_val) = buf_r[0];
  return ret;
}

int eeprom_read(const int fd, const uint addr, const uint offset, unsigned char* buf, uint len) {
  unsigned char tmp = 0;
  int ret = 0;
  if (fd < 0) {
    spdlog::error("failed to open i2cbus");
    return -1;
  }
  for (int i = 0; i < len; i++) {
    ret = read_register_byte(fd, addr + (i / 256), offset + (i & 0xff), &tmp);
    if (ret < 0) {
      return ret;
    }
    buf[i] = tmp;
  }
  return 0;
}

int get_i2c_fd(int& fd, const int i2c_bus, const int flag) {
  std::string si2c_bus = std::to_string(i2c_bus);
  std::stringstream ss;
  ss << std::hex << EEPROM_ADDRESS;
  std::string name_file = "/sys/bus/i2c/devices/" + si2c_bus + "-00" + ss.str() + "/name";
  std::ifstream ifsname_file(name_file);
  if (ifsname_file.is_open()) {
    std::string contents(
        (std::istreambuf_iterator<char>(ifsname_file)), std::istreambuf_iterator<char>());
    ifsname_file.close();
    if (contents != "eeprom_ar0234\n") {
      spdlog::error("Contents of i2c were %s\n", contents.c_str());
      return -1;
    }
  } else {
    spdlog::error("i2c did not have a name at %s\n", name_file.c_str());
    return -1;
  }

  std::string dev = "/dev/i2c-" + si2c_bus;
  fd = open(dev.c_str(), flag);
  if (fd < 0) {
    spdlog::error("Failed to open I2C bus %s\n", dev.c_str());
    return -1;
  }
  return 0;
}
